import json
import re
from typing import List
from .models import GraphFact
from .llms.base import LLMClient


class SemanticExtractor:
    """Extracts subject-relation-object facts from text."""

    def __init__(self, llm: LLMClient | None = None):
        self.llm = llm

    def extract(self, text: str, source: str | None = None, max_chars: int = 6000) -> List[GraphFact]:
        if self.llm is None:
            return self._heuristic_extract(text, source=source)

        prompt = f"""
Extract semantic graph facts from the text.

Return ONLY valid JSON array.
Each item must have:
subject, relation, object, confidence

Rules:
- Keep facts short.
- Avoid duplicates.
- Use relation labels like uses, builds, depends_on, solves, has_metric, created_by.

Text:
{text[:max_chars]}
"""
        raw = self.llm.complete(
            prompt,
            system="You extract clean semantic graph triples as JSON.",
            temperature=0.1
        )
        return self._parse_facts(raw, source=source)

    def _parse_facts(self, raw: str, source: str | None = None) -> List[GraphFact]:
        try:
            data = json.loads(raw)
            if not isinstance(data, list):
                return []
            return [
                GraphFact(
                    subject=str(item.get("subject", "")).strip(),
                    relation=str(item.get("relation", "")).strip(),
                    object=str(item.get("object", "")).strip(),
                    confidence=float(item.get("confidence", 0.8)),
                    source=source
                )
                for item in data
                if item.get("subject") and item.get("relation") and item.get("object")
            ]
        except Exception:
            return self._heuristic_extract(raw, source=source)

    def _heuristic_extract(self, text: str, source: str | None = None) -> List[GraphFact]:
        facts = []
        patterns = [
            (r"([A-Z][A-Za-z0-9_-]+)\s+uses\s+([A-Z][A-Za-z0-9_.-]+)", "uses"),
            (r"([A-Z][A-Za-z0-9_-]+)\s+builds?\s+([A-Z][A-Za-z0-9_.-]+)", "builds"),
            (r"([A-Z][A-Za-z0-9_-]+)\s+predicts?\s+([A-Za-z0-9 _.-]+)", "predicts"),
            (r"([A-Z][A-Za-z0-9_-]+)\s+solves?\s+([A-Za-z0-9 _.-]+)", "solves"),
        ]
        for pattern, rel in patterns:
            for match in re.finditer(pattern, text):
                facts.append(GraphFact(
                    subject=match.group(1).strip(),
                    relation=rel,
                    object=match.group(2).strip().rstrip("."),
                    confidence=0.55,
                    source=source
                ))
        return facts
