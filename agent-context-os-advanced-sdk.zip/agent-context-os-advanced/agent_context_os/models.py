from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field


class GraphFact(BaseModel):
    subject: str
    relation: str
    object: str
    confidence: float = 0.8
    source: Optional[str] = None


class ContextChunk(BaseModel):
    text: str
    source: Optional[str] = None
    score: float = 0.0
    token_estimate: int = 0


class AskResult(BaseModel):
    answer: str
    provider: str
    model_used: str
    original_tokens: int
    optimized_tokens: int
    tokens_saved_percent: float
    context_used: str
    facts_used: List[GraphFact] = Field(default_factory=list)
    compiled_prompt: str
    metadata: Dict[str, Any] = Field(default_factory=dict)
