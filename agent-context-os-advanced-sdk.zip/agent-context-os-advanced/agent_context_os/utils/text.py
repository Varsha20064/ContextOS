import re
from typing import Iterable


def normalize_text(text: str) -> str:
    text = text.replace("\x00", " ")
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def dedupe_sentences(text: str) -> str:
    sentences = re.split(r"(?<=[.!?])\s+", normalize_text(text))
    seen = set()
    out = []
    for sentence in sentences:
        key = sentence.lower().strip()
        if key and key not in seen:
            seen.add(key)
            out.append(sentence.strip())
    return " ".join(out)


def keyword_score(query: str, text: str) -> float:
    q = set(re.findall(r"[a-zA-Z0-9_+-]+", query.lower()))
    t = set(re.findall(r"[a-zA-Z0-9_+-]+", text.lower()))
    if not q:
        return 0.0
    return len(q & t) / len(q)


def join_nonempty(parts: Iterable[str], sep: str = "\n") -> str:
    return sep.join([p for p in parts if p and p.strip()])
