import os
import typer
from rich.console import Console
from rich.table import Table
from dotenv import load_dotenv
from .core import ContextOS

app = typer.Typer(help="Agent Context OS CLI")
console = Console()


def make_ctx(provider: str | None = None) -> ContextOS:
    load_dotenv()
    selected = provider or os.getenv("CONTEXTOS_PROVIDER", "mock")
    ctx = ContextOS(provider=selected)
    ctx.load(".contextos")
    return ctx


@app.command()
def add(path: str, provider: str = typer.Option(None, help="openai, fastrouter, or mock")):
    """Add a text file into local memory and semantic graph."""
    ctx = make_ctx(provider)
    result = ctx.add_file(path)
    ctx.export(".contextos")
    console.print("[green]Added file[/green]", path)
    console.print(result)


@app.command()
def ask(query: str, provider: str = typer.Option(None, help="openai, fastrouter, or mock")):
    """Ask a question using optimized context."""
    ctx = make_ctx(provider)
    result = ctx.ask(query)
    console.print("\n[bold]Answer[/bold]")
    console.print(result.answer)
    console.print("\n[bold]Analytics[/bold]")
    console.print({
        "provider": result.provider,
        "model": result.model_used,
        "original_tokens": result.original_tokens,
        "optimized_tokens": result.optimized_tokens,
        "tokens_saved_percent": result.tokens_saved_percent
    })


@app.command()
def graph():
    """Show graph facts."""
    ctx = make_ctx("mock")
    facts = ctx.graph.facts()
    table = Table(title="Semantic Graph Facts")
    table.add_column("Subject")
    table.add_column("Relation")
    table.add_column("Object")
    for f in facts:
        table.add_row(f.subject, f.relation, f.object)
    console.print(table)


if __name__ == "__main__":
    app()
