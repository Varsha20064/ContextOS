from typing import List
from .models import ContextChunk, GraphFact
from .tokenizer import estimate_tokens
from .utils.text import dedupe_sentences, join_nonempty


class ContextOptimizer:
    def __init__(self, token_budget: int = 3000):
        self.token_budget = token_budget

    def facts_to_text(self, facts: List[GraphFact]) -> str:
        lines = [
            f"- {f.subject} {f.relation.replace('_', ' ')} {f.object}"
            for f in facts
        ]
        return "\n".join(lines)

    def optimize(self, chunks: List[ContextChunk], facts: List[GraphFact] | None = None) -> str:
        facts_text = self.facts_to_text(facts or [])
        chunk_text = join_nonempty([c.text for c in chunks], sep="\n\n")
        combined = join_nonempty([facts_text, chunk_text], sep="\n\n")
        combined = dedupe_sentences(combined)

        words = combined.split()
        approx_tokens = estimate_tokens(combined)
        if approx_tokens <= self.token_budget:
            return combined

        # 1 token ≈ 0.75 words; conservative trim
        max_words = int(self.token_budget * 0.75)
        return " ".join(words[:max_words])
