from typing import List
from .models import ContextChunk
from .tokenizer import estimate_tokens


class TextChunker:
    def __init__(self, max_words: int = 350, overlap_words: int = 40):
        self.max_words = max_words
        self.overlap_words = overlap_words

    def split(self, text: str, source: str | None = None) -> List[ContextChunk]:
        words = text.split()
        if not words:
            return []

        chunks = []
        step = max(1, self.max_words - self.overlap_words)

        for i in range(0, len(words), step):
            part = " ".join(words[i:i + self.max_words])
            chunks.append(ContextChunk(
                text=part,
                source=source,
                token_estimate=estimate_tokens(part)
            ))

        return chunks
