import math


def estimate_tokens(text: str) -> int:
    """Fast rough token estimate. Good enough for dashboards."""
    if not text:
        return 0
    return max(1, math.ceil(len(text) / 4))


def token_savings_percent(original: int, optimized: int) -> float:
    if original <= 0:
        return 0.0
    return round(((original - optimized) / original) * 100, 2)
