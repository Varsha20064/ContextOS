from typing import List
import json
from ..models import ContextChunk
from ..utils.text import keyword_score


class MemoryStore:
    def __init__(self):
        self.chunks: List[ContextChunk] = []

    def add(self, chunk: ContextChunk) -> None:
        self.chunks.append(chunk)

    def add_many(self, chunks: List[ContextChunk]) -> None:
        self.chunks.extend(chunks)

    def search(self, query: str, top_k: int = 8) -> List[ContextChunk]:
        results = []
        for chunk in self.chunks:
            score = keyword_score(query, chunk.text)
            if score > 0:
                chunk.score = score
                results.append(chunk)
        results.sort(key=lambda c: c.score, reverse=True)
        return results[:top_k]

    def save(self, path: str) -> None:
        with open(path, "w", encoding="utf-8") as f:
            json.dump([c.model_dump() for c in self.chunks], f, indent=2)

    def load(self, path: str) -> None:
        with open(path, "r", encoding="utf-8") as f:
            self.chunks = [ContextChunk(**item) for item in json.load(f)]
