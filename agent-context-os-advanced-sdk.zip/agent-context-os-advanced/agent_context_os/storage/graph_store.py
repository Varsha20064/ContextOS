from typing import List, Dict, Any
import json
import networkx as nx
from ..models import GraphFact
from ..utils.text import keyword_score


class GraphStore:
    def __init__(self):
        self.graph = nx.MultiDiGraph()

    def add_fact(self, fact: GraphFact) -> None:
        self.graph.add_node(fact.subject, label=fact.subject)
        self.graph.add_node(fact.object, label=fact.object)
        self.graph.add_edge(
            fact.subject,
            fact.object,
            relation=fact.relation,
            confidence=fact.confidence,
            source=fact.source
        )

    def add_facts(self, facts: List[GraphFact]) -> None:
        for fact in facts:
            self.add_fact(fact)

    def facts(self) -> List[GraphFact]:
        output = []
        for u, v, data in self.graph.edges(data=True):
            output.append(GraphFact(
                subject=u,
                relation=data.get("relation", "related_to"),
                object=v,
                confidence=data.get("confidence", 0.8),
                source=data.get("source")
            ))
        return output

    def search(self, query: str, top_k: int = 12) -> List[GraphFact]:
        scored = []
        for fact in self.facts():
            text = f"{fact.subject} {fact.relation} {fact.object}"
            score = keyword_score(query, text)
            if score > 0:
                scored.append((score, fact))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [f for _, f in scored[:top_k]]

    def to_json(self) -> Dict[str, Any]:
        return {
            "nodes": list(self.graph.nodes(data=True)),
            "edges": [
                {"source": u, "target": v, **data}
                for u, v, data in self.graph.edges(data=True)
            ]
        }

    def save(self, path: str) -> None:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_json(), f, indent=2)

    def load(self, path: str) -> None:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        self.graph.clear()
        for node, attrs in data.get("nodes", []):
            self.graph.add_node(node, **attrs)
        for edge in data.get("edges", []):
            source = edge.pop("source")
            target = edge.pop("target")
            self.graph.add_edge(source, target, **edge)
