class PromptCompiler:
    def compile(self, query: str, context: str, output_style: str = "clear and structured") -> str:
        return f"""
<agent_context_os_prompt>
  <goal>
    Answer the user's query using only the provided optimized context.
  </goal>

  <user_query>
    {query}
  </user_query>

  <optimized_context>
    {context}
  </optimized_context>

  <constraints>
    - Do not invent facts outside the context.
    - Be {output_style}.
    - If the context is insufficient, say what is missing.
  </constraints>
</agent_context_os_prompt>
""".strip()
