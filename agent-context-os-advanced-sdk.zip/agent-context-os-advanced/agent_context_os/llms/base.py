from abc import ABC, abstractmethod


class LLMClient(ABC):
    provider_name: str

    @abstractmethod
    def complete(self, prompt: str, system: str = "", model: str | None = None, temperature: float = 0.2) -> str:
        raise NotImplementedError
