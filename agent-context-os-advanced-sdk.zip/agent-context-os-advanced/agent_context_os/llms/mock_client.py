from .base import LLMClient


class MockClient(LLMClient):
    provider_name = "mock"

    def complete(self, prompt: str, system: str = "", model: str | None = None, temperature: float = 0.2) -> str:
        return "Mock answer generated locally. Replace provider='mock' with 'openai' or 'fastrouter' for real LLM calls."
