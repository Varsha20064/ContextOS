import os
from openai import OpenAI
from .base import LLMClient


class FastRouterClient(LLMClient):
    provider_name = "fastrouter"

    def __init__(self, api_key: str | None = None, base_url: str | None = None):
        self.api_key = api_key or os.getenv("FASTROUTER_API_KEY")
        self.base_url = base_url or os.getenv("FASTROUTER_BASE_URL", "https://api.fastrouter.ai/v1")
        if not self.api_key:
            raise ValueError("FASTROUTER_API_KEY is missing.")
        self.client = OpenAI(api_key=self.api_key, base_url=self.base_url)

    def complete(self, prompt: str, system: str = "", model: str | None = None, temperature: float = 0.2) -> str:
        selected_model = model or os.getenv("CONTEXTOS_MODEL", "openai/gpt-4o-mini")
        response = self.client.chat.completions.create(
            model=selected_model,
            messages=[
                {"role": "system", "content": system or "You are a precise AI assistant."},
                {"role": "user", "content": prompt},
            ],
            temperature=temperature,
        )
        return response.choices[0].message.content or ""
