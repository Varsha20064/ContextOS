import os
from openai import OpenAI
from .base import LLMClient


class OpenAIClient(LLMClient):
    provider_name = "openai"

    def __init__(self, api_key: str | None = None):
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        if not self.api_key:
            raise ValueError("OPENAI_API_KEY is missing.")
        self.client = OpenAI(api_key=self.api_key)

    def complete(self, prompt: str, system: str = "", model: str | None = None, temperature: float = 0.2) -> str:
        selected_model = model or os.getenv("CONTEXTOS_MODEL", "gpt-4.1-mini")
        response = self.client.chat.completions.create(
            model=selected_model,
            messages=[
                {"role": "system", "content": system or "You are a precise AI assistant."},
                {"role": "user", "content": prompt},
            ],
            temperature=temperature,
        )
        return response.choices[0].message.content or ""
