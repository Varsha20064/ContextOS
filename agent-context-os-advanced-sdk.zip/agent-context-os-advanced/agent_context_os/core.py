from pathlib import Path
from dotenv import load_dotenv

from .chunker import TextChunker
from .extractor import SemanticExtractor
from .models import AskResult
from .optimizer import ContextOptimizer
from .prompt_compiler import PromptCompiler
from .router import ModelRouter
from .storage import GraphStore, MemoryStore
from .tokenizer import estimate_tokens, token_savings_percent
from .utils.text import normalize_text


class ContextOS:
    def __init__(
        self,
        provider: str = "openai",
        api_key: str | None = None,
        token_budget: int = 3000,
        use_llm_extractor: bool = True,
    ):
        load_dotenv()
        self.provider = provider
        self.router = ModelRouter(provider=provider, api_key=api_key)
        self.llm = self.router.get_client()
        self.graph = GraphStore()
        self.memory = MemoryStore()
        self.chunker = TextChunker()
        self.optimizer = ContextOptimizer(token_budget=token_budget)
        self.compiler = PromptCompiler()
        self.extractor = SemanticExtractor(self.llm if use_llm_extractor and provider != "mock" else None)

    def add_text(self, text: str, source: str | None = None, extract_graph: bool = True):
        cleaned = normalize_text(text)
        chunks = self.chunker.split(cleaned, source=source)
        self.memory.add_many(chunks)

        facts = []
        if extract_graph:
            facts = self.extractor.extract(cleaned, source=source)
            self.graph.add_facts(facts)

        return {
            "chunks_added": len(chunks),
            "facts_added": len(facts),
            "tokens_added": estimate_tokens(cleaned)
        }

    def add_file(self, path: str, extract_graph: bool = True):
        p = Path(path)
        text = p.read_text(encoding="utf-8", errors="ignore")
        return self.add_text(text, source=str(p), extract_graph=extract_graph)

    def retrieve_context(self, query: str, top_k_chunks: int = 8, top_k_facts: int = 12):
        chunks = self.memory.search(query, top_k=top_k_chunks)
        facts = self.graph.search(query, top_k=top_k_facts)
        optimized = self.optimizer.optimize(chunks=chunks, facts=facts)
        return optimized, chunks, facts

    def ask(
        self,
        query: str,
        model: str | None = None,
        output_style: str = "clear and structured",
        temperature: float = 0.2,
    ) -> AskResult:
        original_context = "\n\n".join([c.text for c in self.memory.chunks])
        original_tokens = estimate_tokens(original_context)

        optimized_context, chunks, facts = self.retrieve_context(query)
        optimized_tokens = estimate_tokens(optimized_context)

        compiled_prompt = self.compiler.compile(
            query=query,
            context=optimized_context,
            output_style=output_style
        )

        model_used = model or self.router.default_model()
        answer = self.llm.complete(
            compiled_prompt,
            system="You are Agent Context OS, an AI context reasoning layer.",
            model=model_used,
            temperature=temperature,
        )

        return AskResult(
            answer=answer,
            provider=self.provider,
            model_used=model_used,
            original_tokens=original_tokens,
            optimized_tokens=optimized_tokens,
            tokens_saved_percent=token_savings_percent(original_tokens, optimized_tokens),
            context_used=optimized_context,
            facts_used=facts,
            compiled_prompt=compiled_prompt,
            metadata={
                "chunks_retrieved": len(chunks),
                "facts_retrieved": len(facts),
            }
        )

    def export(self, folder: str = ".contextos"):
        path = Path(folder)
        path.mkdir(parents=True, exist_ok=True)
        self.graph.save(str(path / "graph.json"))
        self.memory.save(str(path / "memory.json"))
        return str(path)

    def load(self, folder: str = ".contextos"):
        path = Path(folder)
        graph_path = path / "graph.json"
        memory_path = path / "memory.json"
        if graph_path.exists():
            self.graph.load(str(graph_path))
        if memory_path.exists():
            self.memory.load(str(memory_path))
        return self
