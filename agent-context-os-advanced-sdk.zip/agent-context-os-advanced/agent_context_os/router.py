from .llms import OpenAIClient, FastRouterClient, MockClient
from .llms.base import LLMClient


class ModelRouter:
    def __init__(self, provider: str = "openai", api_key: str | None = None):
        self.provider = provider
        self.api_key = api_key

    def get_client(self) -> LLMClient:
        if self.provider == "openai":
            return OpenAIClient(api_key=self.api_key)
        if self.provider == "fastrouter":
            return FastRouterClient(api_key=self.api_key)
        if self.provider == "mock":
            return MockClient()
        raise ValueError(f"Unsupported provider: {self.provider}")

    def default_model(self) -> str:
        if self.provider == "fastrouter":
            return "openai/gpt-4o-mini"
        if self.provider == "mock":
            return "mock-local"
        return "gpt-4.1-mini"
