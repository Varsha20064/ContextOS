import os
from agent_context_os import ContextOS

ctx = ContextOS(provider="openai", api_key=os.getenv("OPENAI_API_KEY"))

ctx.add_text("""
Agent Context OS builds a semantic graph from documents and optimizes context
before sending it to an LLM.
""")

result = ctx.ask("What does Agent Context OS do?")
print(result.answer)
print(result.tokens_saved_percent)
