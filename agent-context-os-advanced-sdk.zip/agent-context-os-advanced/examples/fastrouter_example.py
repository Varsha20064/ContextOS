import os
from agent_context_os import ContextOS

ctx = ContextOS(provider="fastrouter", api_key=os.getenv("FASTROUTER_API_KEY"))

ctx.add_text("""
Agent Context OS can route optimized prompts through FastRouter to compare
models and reduce cost.
""")

result = ctx.ask("Why is FastRouter useful here?")
print(result.answer)
print(result.model_used)
