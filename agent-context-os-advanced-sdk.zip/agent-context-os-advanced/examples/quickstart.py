from agent_context_os import ContextOS

ctx = ContextOS(provider="mock", use_llm_extractor=False)

ctx.add_text("""
OrbitGuard uses CelesTrak, NASA DONKI and NOAA SWPC.
OrbitGuard uses LSTM to predict satellite collision risk.
OrbitGuard solves satellite collision prediction.
""", source="orbitguard-notes")

result = ctx.ask("Explain OrbitGuard architecture")

print(result.answer)
print("Tokens saved:", result.tokens_saved_percent)
print("Context used:")
print(result.context_used)
