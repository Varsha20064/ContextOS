# Agent Context OS

A local-first SDK for building semantic memory graphs, optimizing context, reducing token cost, and routing LLM calls through OpenAI or FastRouter.

## Why

AI agents waste tokens by sending too much irrelevant context. Agent Context OS converts raw text into semantic facts, builds a graph memory, retrieves only relevant facts, compiles prompts, and routes them to the best LLM provider.

## Install locally

```bash
pip install -e .
```

## Environment

```bash
cp .env.example .env
```

Add your keys:

```bash
OPENAI_API_KEY=your_key
FASTROUTER_API_KEY=your_key
```

## Quickstart

```python
from agent_context_os import ContextOS

ctx = ContextOS(provider="openai")

ctx.add_text("""
OrbitGuard uses CelesTrak, NASA DONKI, NOAA SWPC and an LSTM model
to predict satellite collision risk.
""")

result = ctx.ask("Explain OrbitGuard architecture")

print(result.answer)
print(result.tokens_saved_percent)
print(result.model_used)
print(result.context_used)
```

## CLI

```bash
contextos add examples/sample.txt
contextos ask "What is this project about?"
contextos graph
```

## Core features

- Local-first semantic memory
- Entity and relationship extraction
- NetworkX graph backend
- Context ranking
- Context compression
- Prompt compiler
- Token budget manager
- OpenAI adapter
- FastRouter adapter
- CLI
- JSON export/import
- Tests

## Architecture

```text
Documents / Notes / Repo Text
        ↓
Entity + Relationship Extractor
        ↓
Semantic Graph Memory
        ↓
Query Intent + Context Retrieval
        ↓
Context Optimizer + Token Budget
        ↓
Prompt Compiler
        ↓
OpenAI / FastRouter
        ↓
Answer + Analytics
```

## Status

This is an advanced MVP SDK scaffold suitable for hackathons, demos, and open-source extension.
