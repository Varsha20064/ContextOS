from agent_context_os import ContextOS


def test_add_and_ask_mock():
    ctx = ContextOS(provider="mock", use_llm_extractor=False)
    result = ctx.add_text("OrbitGuard uses CelesTrak. OrbitGuard solves satellite collision prediction.")
    assert result["chunks_added"] >= 1

    answer = ctx.ask("What does OrbitGuard use?")
    assert answer.provider == "mock"
    assert answer.optimized_tokens >= 0


def test_graph_fact_heuristic():
    ctx = ContextOS(provider="mock", use_llm_extractor=False)
    ctx.add_text("OrbitGuard uses CelesTrak.")
    facts = ctx.graph.facts()
    assert len(facts) >= 1
