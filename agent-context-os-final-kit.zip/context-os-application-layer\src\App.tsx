import { useMemo, useState } from "react";
import {
  ArrowRight,
  Braces,
  CheckCircle2,
  Copy,
  Download,
  FileText,
  GitBranch,
  Layers3,
  MessageSquareText,
  Play,
  RotateCcw,
  Sparkles,
  UploadCloud,
} from "lucide-react";

type DocumentItem = {
  id: number;
  name: string;
  content: string;
  createdAt: string;
  estimatedTokens: number;
  charCount: number;
  status: "ready" | "processing";
};

type GraphFact = {
  id: string;
  subject: string;
  relation: string;
  object: string;
};

type ReplayStep = {
  label: string;
  detail: string;
};

type ReplayRecord = {
  id: string;
  query: string;
  originalTokens: number;
  optimizedTokens: number;
  savedPercent: number;
  retainedFacts: GraphFact[];
  retainedChunks: string[];
  ignoredSummary: string;
  finalPrompt: string;
  answer: string;
  createdAt: string;
  timeline: ReplayStep[];
};

const starterText =
  "OrbitGuard uses CelesTrak and LSTM for satellite collision prediction. Agent Context OS converts documents into semantic graphs, retrieves graph-based context, optimizes tokens, and sends compact prompts to OpenAI or FastRouter.";

function countTokens(text: string) {
  return (text.match(/\w+|[^\w\s]/g) ?? []).length;
}

function splitSentences(text: string) {
  return text
    .split(/(?<=[.!?])\s+/)
    .map((sentence) => sentence.trim())
    .filter(Boolean);
}

function cleanEntity(value: string) {
  return value
    .replace(/\s+for\s+.+$/i, "")
    .replace(/[.]/g, "")
    .trim();
}

function extractFacts(text: string): GraphFact[] {
  const facts: GraphFact[] = [];
  const patterns = [
    { relation: "uses", regex: /([A-Z][A-Za-z0-9 -]+?)\s+uses\s+([A-Z][A-Za-z0-9 ,&-]+)/g },
    { relation: "converts", regex: /([A-Z][A-Za-z0-9 -]+?)\s+converts\s+([^.!?]+)/g },
    { relation: "retrieves", regex: /([A-Z][A-Za-z0-9 -]+?)\s+retrieves\s+([^.!?]+)/g },
    { relation: "optimizes", regex: /([A-Z][A-Za-z0-9 -]+?)\s+optimizes\s+([^.!?]+)/g },
    { relation: "sends", regex: /([A-Z][A-Za-z0-9 -]+?)\s+sends\s+([^.!?]+)/g },
  ];

  for (const sentence of splitSentences(text)) {
    for (const pattern of patterns) {
      const matches = [...sentence.matchAll(pattern.regex)];
      for (const match of matches) {
        const subject = cleanEntity(match[1]);
        const objects = match[2]
          .split(/\s+and\s+|,|&/)
          .map(cleanEntity)
          .filter(Boolean);
        for (const object of objects) {
          facts.push({
            id: `${subject}-${pattern.relation}-${object}`.toLowerCase().replace(/\s+/g, "-"),
            subject,
            relation: pattern.relation,
            object,
          });
        }
      }
    }
  }

  const unique = new Map<string, GraphFact>();
  for (const fact of facts) unique.set(fact.id, fact);
  return [...unique.values()];
}

function scoreText(query: string, text: string) {
  const terms = query
    .toLowerCase()
    .split(/\W+/)
    .filter((term) => term.length > 2);
  const haystack = text.toLowerCase();
  return terms.reduce((score, term) => score + (haystack.includes(term) ? 1 : 0), 0);
}

function downloadJson(filename: string, data: unknown) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(url);
}

function buildPrompt(query: string, context: string) {
  return `Goal\nAnswer the user using optimized local semantic context.\n\nQuery\n${query}\n\nOptimized context\n${context || "No relevant local context was found."}\n\nConstraints\n- Be concise and accurate.\n- Use semantic graph facts first.\n- If context is insufficient, say what is missing.\n\nOutput format\nAnswer:\nKey graph facts used:\nCaveats:`;
}

export default function App() {
  const [documents, setDocuments] = useState<DocumentItem[]>([
    {
      id: 1,
      name: "OrbitGuard architecture note",
      content: starterText,
      createdAt: new Date().toISOString(),
      estimatedTokens: countTokens(starterText),
      charCount: starterText.length,
      status: "ready",
    },
  ]);
  const [name, setName] = useState("System Architecture v2");
  const [content, setContent] = useState(starterText);
  const [query, setQuery] = useState("Explain OrbitGuard architecture");
  const [activeReplay, setActiveReplay] = useState<ReplayRecord | null>(null);

  const facts = useMemo(() => documents.flatMap((doc) => extractFacts(doc.content)), [documents]);

  const memoryTokens = useMemo(
    () => documents.reduce((sum, doc) => sum + doc.estimatedTokens, 0),
    [documents],
  );

  function addDocument() {
    const trimmed = content.trim();
    if (trimmed.length < 10) return;
    setDocuments((current) => [
      {
        id: Date.now(),
        name: name.trim() || `Context document ${current.length + 1}`,
        content: trimmed,
        createdAt: new Date().toISOString(),
        estimatedTokens: countTokens(trimmed),
        charCount: trimmed.length,
        status: "ready",
      },
      ...current,
    ]);
  }

  function runAgent() {
    const relevantFacts = facts.filter((fact) => scoreText(query, `${fact.subject} ${fact.relation} ${fact.object}`) > 0);
    const selectedFacts = relevantFacts.length ? relevantFacts : facts.slice(0, 4);
    const retainedChunks = documents
      .flatMap((doc) => splitSentences(doc.content))
      .filter((sentence) => scoreText(query, sentence) > 0)
      .slice(0, 4);
    const context = [
      ...selectedFacts.map((fact) => `${fact.subject} ${fact.relation} ${fact.object}.`),
      ...retainedChunks,
    ].join("\n");
    const originalTokens = countTokens(documents.map((doc) => doc.content).join("\n"));
    const optimizedTokens = countTokens(context);
    const savedPercent = originalTokens
      ? Math.max(0, Math.round(((originalTokens - optimizedTokens) / originalTokens) * 100))
      : 0;
    const finalPrompt = buildPrompt(query, context);
    const answer = `Answer:\nAgent Context OS keeps source content, semantic facts, optimized context, prompt compilation, and replay in one application layer. For this query, it retained ${selectedFacts.length} graph facts and ${retainedChunks.length} source chunks before compiling the prompt.\n\nKey graph facts used:\n${selectedFacts.map((fact) => `- ${fact.subject} -> ${fact.relation} -> ${fact.object}`).join("\n") || "- No graph facts retained"}\n\nCaveats:\n- This preview runs locally in mock mode.`;

    setActiveReplay({
      id: crypto.randomUUID(),
      query,
      originalTokens,
      optimizedTokens,
      savedPercent,
      retainedFacts: selectedFacts,
      retainedChunks,
      ignoredSummary: `Ignored ${Math.max(0, facts.length - selectedFacts.length)} graph facts and ${Math.max(0, documents.length - retainedChunks.length)} lower relevance source areas.`,
      finalPrompt,
      answer,
      createdAt: new Date().toISOString(),
      timeline: [
        { label: "Source loaded", detail: `${documents.length} document(s) available in local memory.` },
        { label: "Graph extracted", detail: `${facts.length} semantic relation(s) created.` },
        { label: "Context retrieved", detail: `${selectedFacts.length} graph fact(s), ${retainedChunks.length} chunk(s).` },
        { label: "Context optimized", detail: `${originalTokens} -> ${optimizedTokens} tokens, ${savedPercent}% saved.` },
        { label: "Prompt compiled", detail: "Structured prompt produced for the model layer." },
        { label: "Response generated", detail: "Mock agent response created locally." },
      ],
    });
  }

  function resetWorkspace() {
    setDocuments([]);
    setActiveReplay(null);
  }

  return (
    <main className="app-shell">
      <header className="command-bar">
        <div className="brand-lockup">
          <div className="brand-mark">C</div>
          <div>
            <p className="eyebrow">Agent Context OS</p>
            <h1>Application Layer</h1>
          </div>
        </div>
        <div className="command-actions">
          <button className="ghost" onClick={resetWorkspace} type="button">
            <RotateCcw size={16} /> Reset
          </button>
          <button
            className="ghost"
            onClick={() => downloadJson("context-os-export.json", { documents, facts, replay: activeReplay })}
            type="button"
          >
            <Download size={16} /> Export
          </button>
          <button className="primary" onClick={runAgent} type="button">
            <Play size={16} /> Run context
          </button>
        </div>
      </header>

      <section className="system-strip">
        <div>
          <span>Documents</span>
          <strong>{documents.length}</strong>
        </div>
        <div>
          <span>Graph facts</span>
          <strong>{facts.length}</strong>
        </div>
        <div>
          <span>Memory tokens</span>
          <strong>{memoryTokens}</strong>
        </div>
        <div>
          <span>Mode</span>
          <strong>Local mock</strong>
        </div>
      </section>

      <section className="workspace-grid">
        <aside className="layer-panel source-layer">
          <div className="layer-heading">
            <UploadCloud size={18} />
            <div>
              <h2>Source Layer</h2>
              <p>Paste text or architecture notes into local memory.</p>
            </div>
          </div>
          <label>
            Document name
            <input value={name} onChange={(event) => setName(event.target.value)} />
          </label>
          <label>
            Raw content
            <textarea value={content} onChange={(event) => setContent(event.target.value)} />
          </label>
          <button className="primary wide" onClick={addDocument} type="button">
            <FileText size={16} /> Add to memory
          </button>

          <div className="document-list">
            {documents.length === 0 ? (
              <p className="empty">No documents loaded.</p>
            ) : (
              documents.map((doc) => (
                <article key={doc.id}>
                  <FileText size={16} />
                  <div>
                    <strong>{doc.name}</strong>
                    <span>{doc.estimatedTokens} tokens | {doc.charCount} chars</span>
                  </div>
                </article>
              ))
            )}
          </div>
        </aside>

        <section className="layer-panel context-layer">
          <div className="layer-heading">
            <GitBranch size={18} />
            <div>
              <h2>Semantic Context Layer</h2>
              <p>Graph facts, retained chunks, and token optimization in one view.</p>
            </div>
          </div>

          <div className="graph-board">
            {facts.length === 0 ? (
              <div className="empty-state"><Braces size={28} /> Add text to generate graph facts.</div>
            ) : (
              facts.map((fact) => (
                <div className="fact-row" key={fact.id}>
                  <span>{fact.subject}</span>
                  <ArrowRight size={14} />
                  <em>{fact.relation}</em>
                  <ArrowRight size={14} />
                  <span>{fact.object}</span>
                </div>
              ))
            )}
          </div>

          <div className="optimizer-card">
            <div>
              <p className="eyebrow">Token optimizer</p>
              <h3>{activeReplay ? `${activeReplay.savedPercent}% saved` : "Ready to optimize"}</h3>
            </div>
            <div className="token-meter">
              <span style={{ width: `${activeReplay ? Math.max(8, 100 - activeReplay.savedPercent) : 100}%` }} />
            </div>
            <p>{activeReplay ? activeReplay.ignoredSummary : "Run context to see retained facts and ignored context."}</p>
          </div>

          <div className="timeline">
            {(activeReplay?.timeline ?? [
              { label: "Waiting", detail: "Load source text, then run context." },
            ]).map((step) => (
              <div key={`${step.label}-${step.detail}`}>
                <CheckCircle2 size={16} />
                <p><strong>{step.label}</strong><span>{step.detail}</span></p>
              </div>
            ))}
          </div>
        </section>

        <aside className="layer-panel agent-layer">
          <div className="layer-heading">
            <MessageSquareText size={18} />
            <div>
              <h2>Agent Layer</h2>
              <p>Ask with optimized semantic context and inspect the prompt.</p>
            </div>
          </div>
          <label>
            Query
            <textarea className="query-box" value={query} onChange={(event) => setQuery(event.target.value)} />
          </label>
          <button className="primary wide" onClick={runAgent} type="button">
            <Sparkles size={16} /> Ask with context
          </button>

          <div className="answer-box">
            <div className="answer-header">
              <h3>Agent response</h3>
              <button className="icon-button" onClick={() => navigator.clipboard?.writeText(activeReplay?.answer ?? "")} type="button">
                <Copy size={15} />
              </button>
            </div>
            <pre>{activeReplay?.answer ?? "Run a query to generate an optimized local response."}</pre>
          </div>

          <div className="prompt-box">
            <div className="answer-header">
              <h3>Compiled prompt</h3>
              <Layers3 size={15} />
            </div>
            <pre>{activeReplay?.finalPrompt ?? "The structured prompt will appear here after context optimization."}</pre>
          </div>
        </aside>
      </section>
    </main>
  );
}
