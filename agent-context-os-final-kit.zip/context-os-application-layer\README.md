# Agent Context OS Application Layer

This is a standalone Vite + React application layer for Agent Context OS. It is not a dashboard. It presents the product as a focused local workspace with three layers:

- Source Layer: add raw documents or architecture notes
- Semantic Context Layer: inspect extracted graph facts, token optimization, and replay timeline
- Agent Layer: ask questions, view the optimized response, and inspect the compiled prompt

## Run locally

```powershell
npm install
npm run dev
```

Open:

```text
http://localhost:5173/
```

You do not need to set `PORT` or `BASE_PATH`. Defaults are already included:

- `PORT=5173`
- `BASE_PATH=/`

Optional:

```powershell
$env:PORT=3000; $env:BASE_PATH="/"; npm run dev
```

## Build

```powershell
npm run typecheck
npm run build
```

## What was fixed

- Removed required `PORT` and `BASE_PATH` crashes.
- Removed dashboard/sidebar routing from the active app.
- Removed dependency on `@workspace/api-client-react` from the active app.
- Avoided the `documents?.map is not a function` runtime error by using local array state.
- Replaced Tailwind-dependent screen styling with plain CSS so the UI does not render as unstyled text.
- Verified production build and TypeScript typecheck.
