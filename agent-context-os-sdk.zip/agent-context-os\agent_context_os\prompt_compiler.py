class PromptCompiler:
    """Compile optimized context into a structured prompt."""

    def compile(self, query: str, optimized_context: str) -> str:
        return f"""Goal
Answer the user using only the optimized context when possible.

Query
{query}

Optimized context
{optimized_context or "No relevant local context was found."}

Constraints
- Be concise and accurate.
- If context is insufficient, say what is missing.
- Preserve important entities, relationships, and architecture details.

Output format
Answer:
- Direct answer
- Key graph facts used
- Caveats, if any
""".strip()
