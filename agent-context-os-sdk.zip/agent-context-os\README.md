# Agent Context OS

Agent Context OS is a local-first Python SDK for converting documents and text into semantic graphs, retrieving graph-aware context, optimizing token usage, and sending compact prompts to OpenAI, FastRouter, or a local mock model.

It is designed for developers building AI agents that need better memory than plain text stuffing. Instead of sending every uploaded document into every prompt, Agent Context OS extracts entity-relation facts, keeps local document chunks, retrieves only relevant context, and records a replay trail for every model call.

## Installation

```bash
cd agent-context-os
pip install -e .
```

For tests:

```bash
pip install -e ".[dev]"
pytest
```

## Quickstart

```python
from agent_context_os import ContextOS

ctx = ContextOS(provider="mock")
ctx.add_text("OrbitGuard uses CelesTrak and LSTM for satellite collision prediction.")

result = ctx.ask("Explain OrbitGuard architecture")

print(result.answer)
print(result.semantic_graph)
print(result.tokens_saved_percent)
```

Mock mode works locally without API keys and is useful for tests, demos, and offline development.

## OpenAI Setup

Install the SDK and set your environment variable:

```bash
export OPENAI_API_KEY="your-key"
```

Windows PowerShell:

```powershell
$env:OPENAI_API_KEY="your-key"
```

Then use:

```python
ctx = ContextOS(provider="openai")
```

The OpenAI client uses the official `openai` Python package.

## FastRouter Setup

FastRouter uses an OpenAI-compatible API style.

```bash
export FASTROUTER_API_KEY="your-key"
export FASTROUTER_BASE_URL="https://api.fastrouter.ai/v1"
```

Windows PowerShell:

```powershell
$env:FASTROUTER_API_KEY="your-key"
$env:FASTROUTER_BASE_URL="https://api.fastrouter.ai/v1"
```

Then use:

```python
ctx = ContextOS(provider="fastrouter")
```

## CLI Usage

After installation, the `contextos` command is available:

```bash
contextos add path/to/file.txt
contextos ask "What is this project about?"
contextos graph
contextos replay
contextos export contextos_export
```

Provider can be selected per command:

```bash
contextos ask "Explain the architecture" --provider openai
contextos ask "Explain the architecture" --provider fastrouter
contextos ask "Explain the architecture" --provider mock
```

## Exports

The SDK can export local context artifacts:

```python
ctx.export("contextos_export")
```

This creates:

- `semantic_graph.json`
- `memory.json`
- `replay.json`

## Architecture

```text
Documents / Text
      |
      v
SemanticExtractor
      |    uses OpenAI / FastRouter when keys exist
      |    falls back to mock local extraction
      v
GraphStore (NetworkX MultiDiGraph) ---- Document Chunks
      |                                  |
      +---------- ContextOptimizer ------+
                         |
                         v
                  PromptCompiler
                         |
                         v
ModelRouter -> OpenAI / FastRouter / Mock
                         |
                         v
AskResult + Agent Replay + Context Diff
```

## Why Semantic Graph Context Helps

Plain text retrieval often returns long chunks that contain only a few useful facts. Agent Context OS keeps both document chunks and graph facts like:

```text
OrbitGuard -> uses -> CelesTrak
OrbitGuard -> uses -> LSTM
```

When a user asks about OrbitGuard architecture, the SDK can retain the graph facts that explain the system while ignoring unrelated document text. This makes prompts smaller, easier to inspect, and more reliable for agent workflows.

## Token Savings

For every `ctx.ask()`, the optimizer compares:

- original token count from local memory and graph facts
- optimized token count after relevance selection and deduplication
- percentage saved

The result includes:

```python
result.original_tokens
result.optimized_tokens
result.tokens_saved_percent
```

## Agent Replay and Context Diff

Every question creates a replay record with:

- query ID
- original token count
- optimized token count
- tokens saved percent
- semantic facts retained
- chunks retained
- removed or ignored context summary
- final prompt sent to the LLM
- provider and model selected
- timestamp
- step-by-step timeline

Use:

```python
replay = ctx.get_replay(result.query_id)
all_replays = ctx.list_replays()
```

## Examples

Run these after installation:

```bash
python examples/quickstart.py
python examples/openai_example.py
python examples/fastrouter_example.py
```

## Local-First Defaults

Agent Context OS is designed to run on any developer machine:

- no API keys required in mock mode
- local NetworkX semantic graph
- local replay records
- local JSON export
- clean Python package structure ready for GitHub

## License

MIT
