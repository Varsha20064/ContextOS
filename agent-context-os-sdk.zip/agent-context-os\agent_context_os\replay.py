from __future__ import annotations

import json
from pathlib import Path

from agent_context_os.models import ReplayRecord


class ReplayStore:
    def __init__(self) -> None:
        self._records: dict[str, ReplayRecord] = {}

    def add(self, replay: ReplayRecord) -> None:
        self._records[replay.query_id] = replay

    def get(self, query_id: str) -> ReplayRecord | None:
        return self._records.get(query_id)

    def list(self) -> list[ReplayRecord]:
        return list(self._records.values())

    def export_json(self, path: str | Path) -> None:
        payload = [record.model_dump(mode="json") for record in self.list()]
        Path(path).write_text(json.dumps(payload, indent=2), encoding="utf-8")
