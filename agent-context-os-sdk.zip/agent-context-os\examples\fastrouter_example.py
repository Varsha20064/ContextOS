from agent_context_os import ContextOS

ctx = ContextOS(provider="fastrouter")
ctx.add_text("Agent Context OS converts documents into semantic graphs for agent memory.")
result = ctx.ask("What does Agent Context OS do?")
print(result.answer)
