from __future__ import annotations

import json
import os
import re
from typing import Iterable

from dotenv import load_dotenv

from agent_context_os.models import GraphFact

load_dotenv()


class SemanticExtractor:
    """Extract entity-relation triples using an LLM when available, otherwise local rules."""

    def __init__(self, provider: str = "mock") -> None:
        self.provider = provider

    def extract(self, text: str) -> list[GraphFact]:
        if self.provider == "openai" and os.getenv("OPENAI_API_KEY"):
            return self._llm_extract(text, provider="openai")
        if self.provider == "fastrouter" and os.getenv("FASTROUTER_API_KEY"):
            return self._llm_extract(text, provider="fastrouter")
        return self._mock_extract(text)

    def _llm_extract(self, text: str, provider: str) -> list[GraphFact]:
        prompt = (
            "Extract semantic triples from the text. Return only JSON as a list of "
            "objects with subject, relation, object, confidence.\n\nText:\n"
            f"{text}"
        )
        if provider == "openai":
            from agent_context_os.llms.openai_client import OpenAIClient

            client = OpenAIClient()
        else:
            from agent_context_os.llms.fastrouter_client import FastRouterClient

            client = FastRouterClient()
        response = client.complete(prompt)
        try:
            payload = json.loads(response.text)
            return [
                GraphFact(
                    subject=str(item["subject"]).strip(),
                    relation=str(item["relation"]).strip(),
                    object=str(item["object"]).strip(),
                    source=provider,
                    confidence=float(item.get("confidence", 0.85)),
                )
                for item in payload
                if item.get("subject") and item.get("relation") and item.get("object")
            ]
        except Exception:
            return self._mock_extract(text)

    def _mock_extract(self, text: str) -> list[GraphFact]:
        facts: list[GraphFact] = []
        sentences = self._sentences(text)
        patterns = [
            (r"(?P<s>[A-Z][A-Za-z0-9_ -]+?)\s+uses\s+(?P<o>[A-Z][A-Za-z0-9_ -]+)", "uses"),
            (r"(?P<s>[A-Z][A-Za-z0-9_ -]+?)\s+is built with\s+(?P<o>[A-Z][A-Za-z0-9_ -]+)", "is built with"),
            (r"(?P<s>[A-Z][A-Za-z0-9_ -]+?)\s+supports\s+(?P<o>[A-Z][A-Za-z0-9_ -]+)", "supports"),
            (r"(?P<s>[A-Z][A-Za-z0-9_ -]+?)\s+integrates with\s+(?P<o>[A-Z][A-Za-z0-9_ -]+)", "integrates with"),
            (r"(?P<s>[A-Z][A-Za-z0-9_ -]+?)\s+converts\s+(?P<o>.+)", "converts"),
        ]

        for sentence in sentences:
            for pattern, relation in patterns:
                match = re.search(pattern, sentence)
                if match:
                    subject = self._clean_entity(match.group("s"))
                    objects = self._split_objects(match.group("o"))
                    for obj in objects:
                        facts.append(
                            GraphFact(
                                subject=subject,
                                relation=relation,
                                object=self._clean_entity(obj),
                                source="mock",
                                confidence=0.7,
                            )
                        )
                    break

        if not facts:
            facts.extend(self._keyword_facts(text))
        return self._dedupe(facts)

    @staticmethod
    def _sentences(text: str) -> list[str]:
        return [part.strip() for part in re.split(r"(?<=[.!?])\s+", text) if part.strip()]

    @staticmethod
    def _split_objects(value: str) -> list[str]:
        value = re.sub(r"\.$", "", value.strip())
        return [part.strip() for part in re.split(r"\s+and\s+|,", value) if part.strip()]

    @staticmethod
    def _clean_entity(value: str) -> str:
        value = re.sub(r"\s+for\s+.+$", "", value.strip(), flags=re.I).strip()
        value = re.sub(r"\b(for|to|from|with)$", "", value, flags=re.I).strip()
        return re.sub(r"\s+", " ", value).strip(" .")

    def _keyword_facts(self, text: str) -> Iterable[GraphFact]:
        words = re.findall(r"\b[A-Z][A-Za-z0-9_]{2,}\b", text)
        if len(words) >= 2:
            subject = words[0]
            for obj in words[1:5]:
                if obj != subject:
                    yield GraphFact(subject=subject, relation="mentions", object=obj, source="mock", confidence=0.45)

    @staticmethod
    def _dedupe(facts: Iterable[GraphFact]) -> list[GraphFact]:
        seen: set[tuple[str, str, str]] = set()
        unique: list[GraphFact] = []
        for fact in facts:
            key = (fact.subject.lower(), fact.relation.lower(), fact.object.lower())
            if key not in seen:
                seen.add(key)
                unique.append(fact)
        return unique

