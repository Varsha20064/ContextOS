from __future__ import annotations

import os

from dotenv import load_dotenv

from agent_context_os.models import LLMResponse

load_dotenv()


class FastRouterClient:
    def __init__(self, model: str | None = None) -> None:
        self.model = model or os.getenv("FASTROUTER_MODEL", "openai/gpt-4o-mini")
        self.base_url = os.getenv("FASTROUTER_BASE_URL", "https://api.fastrouter.ai/v1")
        self.client = None
        if os.getenv("FASTROUTER_API_KEY"):
            from openai import OpenAI

            self.client = OpenAI(api_key=os.getenv("FASTROUTER_API_KEY"), base_url=self.base_url)

    def complete(self, prompt: str) -> LLMResponse:
        if self.client is None:
            return LLMResponse(
                text="FastRouter API key is missing. Set FASTROUTER_API_KEY or use provider='mock'.",
                provider="fastrouter",
                model=self.model,
            )
        response = self.client.chat.completions.create(
            model=self.model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
        )
        return LLMResponse(
            text=response.choices[0].message.content or "",
            provider="fastrouter",
            model=self.model,
            raw=response.model_dump(),
        )
