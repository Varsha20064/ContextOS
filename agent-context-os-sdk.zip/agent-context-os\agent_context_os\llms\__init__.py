"""LLM clients for Agent Context OS."""

__all__ = ["FastRouterClient", "MockClient", "OpenAIClient"]


def __getattr__(name: str):
    if name == "OpenAIClient":
        from agent_context_os.llms.openai_client import OpenAIClient

        return OpenAIClient
    if name == "FastRouterClient":
        from agent_context_os.llms.fastrouter_client import FastRouterClient

        return FastRouterClient
    if name == "MockClient":
        from agent_context_os.llms.mock_client import MockClient

        return MockClient
    raise AttributeError(name)
