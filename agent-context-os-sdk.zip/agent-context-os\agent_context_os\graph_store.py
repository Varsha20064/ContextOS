from __future__ import annotations

import json
from pathlib import Path

import networkx as nx

from agent_context_os.models import GraphFact


class GraphStore:
    """NetworkX-backed local semantic graph store."""

    def __init__(self) -> None:
        self.graph = nx.MultiDiGraph()
        self.facts: list[GraphFact] = []

    def add_facts(self, facts: list[GraphFact]) -> None:
        for fact in facts:
            key = (fact.subject.lower(), fact.relation.lower(), fact.object.lower())
            if any((f.subject.lower(), f.relation.lower(), f.object.lower()) == key for f in self.facts):
                continue
            self.facts.append(fact)
            self.graph.add_node(fact.subject, label=fact.subject)
            self.graph.add_node(fact.object, label=fact.object)
            self.graph.add_edge(
                fact.subject,
                fact.object,
                relation=fact.relation,
                fact_source=fact.source,
                confidence=fact.confidence,
            )

    def search(self, query: str, limit: int = 20) -> list[GraphFact]:
        terms = {term.lower() for term in query.split() if len(term) > 2}
        scored: list[tuple[int, GraphFact]] = []
        for fact in self.facts:
            haystack = f"{fact.subject} {fact.relation} {fact.object}".lower()
            score = sum(1 for term in terms if term in haystack)
            if score:
                scored.append((score, fact))
        if not scored:
            return self.facts[:limit]
        return [fact for _, fact in sorted(scored, key=lambda item: item[0], reverse=True)[:limit]]

    def to_dict(self) -> dict:
        return {
            "nodes": [{"id": node, **attrs} for node, attrs in self.graph.nodes(data=True)],
            "edges": [
                {**attrs, "source": source, "target": target}
                for source, target, attrs in self.graph.edges(data=True)
            ],
            "facts": [fact.model_dump() for fact in self.facts],
        }

    def export_json(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps(self.to_dict(), indent=2), encoding="utf-8")

