from agent_context_os import ContextOS


def test_sdk_initializes_in_mock_mode():
    ctx = ContextOS(provider="mock")
    assert ctx.provider == "mock"


def test_text_can_be_added_and_graph_facts_created():
    ctx = ContextOS(provider="mock")
    facts = ctx.add_text("OrbitGuard uses CelesTrak and LSTM for satellite collision prediction.")
    assert len(facts) >= 2
    graph = ctx.semantic_graph
    assert any(fact["subject"] == "OrbitGuard" for fact in graph["facts"])
    assert any(edge["source"] == "OrbitGuard" and edge["target"] == "CelesTrak" for edge in graph["edges"])


def test_ask_returns_response_and_replay():
    ctx = ContextOS(provider="mock")
    ctx.add_text("OrbitGuard uses CelesTrak and LSTM for satellite collision prediction.")
    result = ctx.ask("Explain OrbitGuard architecture")
    assert result.answer
    assert result.query_id
    assert result.tokens_saved_percent >= 0
    replay = ctx.get_replay(result.query_id)
    assert replay is not None
    assert replay.final_prompt
    assert len(ctx.list_replays()) == 1

