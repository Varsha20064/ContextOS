import re


def count_tokens(text: str) -> int:
    """Approximate token count without external tokenizer dependencies."""
    if not text:
        return 0
    return len(re.findall(r"\w+|[^\w\s]", text, flags=re.UNICODE))
