from agent_context_os import ContextOS

ctx = ContextOS(provider="openai")
ctx.add_text("OrbitGuard uses CelesTrak and LSTM for satellite collision prediction.")
result = ctx.ask("Explain OrbitGuard architecture")
print(result.answer)
