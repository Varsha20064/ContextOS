from __future__ import annotations

import json
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from agent_context_os import ContextOS
from agent_context_os.models import ReplayRecord

app = typer.Typer(help="Agent Context OS local-first semantic context CLI.")
console = Console()
STATE_DIR = Path(".contextos")
STATE_FILE = STATE_DIR / "memory.json"


def _load_ctx(provider: str = "mock") -> ContextOS:
    ctx = ContextOS(provider=provider, storage_dir=STATE_DIR)
    if STATE_FILE.exists():
        payload = json.loads(STATE_FILE.read_text(encoding="utf-8"))
        for chunk in payload.get("chunks", []):
            ctx.add_text(chunk.get("text", ""), source=chunk.get("source", "cli"))
        for replay_payload in payload.get("replays", []):
            ctx.replays.add(ReplayRecord.model_validate(replay_payload))
    return ctx


def _save_ctx(ctx: ContextOS) -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    STATE_FILE.write_text(
        json.dumps(
            {
                "chunks": [chunk.model_dump() for chunk in ctx.memory],
                "replays": [record.model_dump(mode="json") for record in ctx.list_replays()],
            },
            indent=2,
        ),
        encoding="utf-8",
    )


@app.command()
def add(path: Path, provider: str = typer.Option("mock", help="openai, fastrouter, or mock")) -> None:
    """Add a text file to local memory."""
    ctx = _load_ctx(provider)
    facts = ctx.add_file(path)
    _save_ctx(ctx)
    console.print(f"[green]Added[/green] {path} and extracted {len(facts)} facts.")


@app.command()
def ask(query: str, provider: str = typer.Option("mock", help="openai, fastrouter, or mock")) -> None:
    """Ask a question against local semantic context."""
    ctx = _load_ctx(provider)
    result = ctx.ask(query)
    _save_ctx(ctx)
    console.print(result.answer)
    console.print(f"\n[cyan]Tokens saved:[/cyan] {result.tokens_saved_percent}%")
    console.print(f"[cyan]Replay ID:[/cyan] {result.query_id}")


@app.command()
def graph(provider: str = typer.Option("mock", help="openai, fastrouter, or mock")) -> None:
    """Print semantic graph facts."""
    ctx = _load_ctx(provider)
    table = Table(title="Semantic Graph")
    table.add_column("Subject")
    table.add_column("Relation")
    table.add_column("Object")
    for fact in ctx.semantic_graph["facts"]:
        table.add_row(fact["subject"], fact["relation"], fact["object"])
    console.print(table)


@app.command()
def replay(provider: str = typer.Option("mock", help="openai, fastrouter, or mock")) -> None:
    """List replay records."""
    ctx = _load_ctx(provider)
    records = ctx.list_replays()
    if not records:
        console.print("No replay records yet. Run contextos ask first.")
        return
    for record in records:
        console.print(record.model_dump_json(indent=2))


@app.command("export")
def export_cmd(
    output_dir: Path = typer.Argument(Path("contextos_export")),
    provider: str = typer.Option("mock", help="openai, fastrouter, or mock"),
) -> None:
    """Export semantic_graph.json, memory.json, and replay.json."""
    ctx = _load_ctx(provider)
    paths = ctx.export(output_dir)
    for label, path in paths.items():
        console.print(f"[green]{label}[/green]: {path}")


def main() -> None:
    app()


if __name__ == "__main__":
    main()
