from __future__ import annotations

import re

from agent_context_os.models import DocumentChunk, GraphFact, OptimizationResult
from agent_context_os.tokenizer import count_tokens


class ContextOptimizer:
    """Select relevant graph facts and chunks while respecting a token budget."""

    def __init__(self, token_budget: int = 1200) -> None:
        self.token_budget = token_budget

    def optimize(
        self,
        query: str,
        chunks: list[DocumentChunk],
        graph_facts: list[GraphFact],
        token_budget: int | None = None,
    ) -> OptimizationResult:
        budget = token_budget or self.token_budget
        original_context = "\n".join([chunk.text for chunk in chunks] + [fact.as_sentence() for fact in graph_facts])
        original_tokens = count_tokens(original_context)

        retained_facts = self._rank_facts(query, graph_facts)
        retained_chunks = self._rank_chunks(query, chunks)

        lines: list[str] = []
        selected_facts: list[GraphFact] = []
        selected_chunks: list[DocumentChunk] = []
        seen_sentences: set[str] = set()

        for fact in retained_facts:
            sentence = fact.as_sentence()
            if self._add_line(lines, sentence, seen_sentences, budget):
                selected_facts.append(fact)

        for chunk in retained_chunks:
            chosen_sentences = []
            for sentence in self._sentences(chunk.text):
                if self._is_relevant(query, sentence) and self._add_line(lines, sentence, seen_sentences, budget):
                    chosen_sentences.append(sentence)
            if chosen_sentences:
                selected_chunks.append(DocumentChunk(id=chunk.id, text=" ".join(chosen_sentences), source=chunk.source))

        context = "\n".join(lines).strip()
        optimized_tokens = count_tokens(context)
        saved = 0.0
        if original_tokens:
            saved = round(max(0, (original_tokens - optimized_tokens) / original_tokens) * 100, 2)

        removed_count = max(0, len(chunks) - len(selected_chunks))
        ignored_facts = max(0, len(graph_facts) - len(selected_facts))
        summary = f"Ignored {removed_count} less relevant chunks and {ignored_facts} less relevant graph facts."

        return OptimizationResult(
            context=context,
            original_tokens=original_tokens,
            optimized_tokens=optimized_tokens,
            tokens_saved_percent=saved,
            semantic_facts_retained=selected_facts,
            chunks_retained=selected_chunks,
            removed_context_summary=summary,
        )

    def _rank_facts(self, query: str, facts: list[GraphFact]) -> list[GraphFact]:
        return sorted(facts, key=lambda fact: self._score(query, fact.as_sentence()), reverse=True)

    def _rank_chunks(self, query: str, chunks: list[DocumentChunk]) -> list[DocumentChunk]:
        return sorted(chunks, key=lambda chunk: self._score(query, chunk.text), reverse=True)

    def _add_line(self, lines: list[str], line: str, seen: set[str], budget: int) -> bool:
        normalized = re.sub(r"\s+", " ", line.strip().lower())
        if not normalized or normalized in seen:
            return False
        candidate = "\n".join(lines + [line])
        if count_tokens(candidate) > budget:
            return False
        seen.add(normalized)
        lines.append(line.strip())
        return True

    def _is_relevant(self, query: str, text: str) -> bool:
        return self._score(query, text) > 0 or len(query.split()) <= 2

    @staticmethod
    def _score(query: str, text: str) -> int:
        terms = {term.lower().strip("?.!,") for term in query.split() if len(term) > 2}
        haystack = text.lower()
        return sum(1 for term in terms if term in haystack)

    @staticmethod
    def _sentences(text: str) -> list[str]:
        return [part.strip() for part in re.split(r"(?<=[.!?])\s+", text) if part.strip()]
