from agent_context_os import ContextOS

ctx = ContextOS(provider="mock")
ctx.add_text("OrbitGuard uses CelesTrak and LSTM for satellite collision prediction.")

result = ctx.ask("Explain OrbitGuard architecture")

print(result.answer)
print(result.semantic_graph)
print(f"Tokens saved: {result.tokens_saved_percent}%")
print(f"Replay ID: {result.query_id}")
