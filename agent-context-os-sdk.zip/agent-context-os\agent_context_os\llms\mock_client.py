from __future__ import annotations

import re

from agent_context_os.models import LLMResponse


class MockClient:
    """Local deterministic model client for offline development and tests."""

    def __init__(self, model: str | None = None) -> None:
        self.model = model or "mock-contextos-local"

    def complete(self, prompt: str) -> LLMResponse:
        query = self._section(prompt, "Query") or "the request"
        context = self._section(prompt, "Optimized context")
        facts = [line.strip() for line in context.splitlines() if " " in line][:5]
        fact_block = "\n".join(f"- {fact}" for fact in facts) or "- No local graph facts were available."
        text = (
            "Answer:\n"
            f"Agent Context OS mock response for: {query.strip()}\n\n"
            "Key graph facts used:\n"
            f"{fact_block}\n\n"
            "Caveats, if any:\n"
            "- This response was generated locally in mock mode."
        )
        return LLMResponse(text=text, provider="mock", model=self.model)

    @staticmethod
    def _section(prompt: str, title: str) -> str:
        pattern = rf"{re.escape(title)}\n(.*?)(?:\n\n[A-Z][A-Za-z ]+\n|$)"
        match = re.search(pattern, prompt, flags=re.S)
        return match.group(1).strip() if match else ""
