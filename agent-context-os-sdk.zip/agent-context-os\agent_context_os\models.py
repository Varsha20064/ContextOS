from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from pydantic import BaseModel, Field


class GraphFact(BaseModel):
    subject: str
    relation: str
    object: str
    source: str = "local"
    confidence: float = 0.75

    def as_sentence(self) -> str:
        return f"{self.subject} {self.relation} {self.object}."


class DocumentChunk(BaseModel):
    id: str
    text: str
    source: str = "inline"


class OptimizationResult(BaseModel):
    context: str
    original_tokens: int
    optimized_tokens: int
    tokens_saved_percent: float
    semantic_facts_retained: list[GraphFact] = Field(default_factory=list)
    chunks_retained: list[DocumentChunk] = Field(default_factory=list)
    removed_context_summary: str = ""


class LLMResponse(BaseModel):
    text: str
    provider: str
    model: str
    raw: dict[str, Any] = Field(default_factory=dict)


class ReplayStep(BaseModel):
    event: str
    detail: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class ReplayRecord(BaseModel):
    query_id: str
    original_token_count: int
    optimized_token_count: int
    tokens_saved_percent: float
    semantic_facts_retained: list[GraphFact]
    chunks_retained: list[DocumentChunk]
    removed_context_summary: str
    final_prompt: str
    provider: str
    model: str
    timestamp: datetime
    timeline: list[ReplayStep]


class AskResult(BaseModel):
    query_id: str
    answer: str
    semantic_graph: dict[str, Any]
    tokens_saved_percent: float
    original_tokens: int
    optimized_tokens: int
    replay: ReplayRecord
