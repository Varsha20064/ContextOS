from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from uuid import uuid4

from agent_context_os.context_optimizer import ContextOptimizer
from agent_context_os.extractor import SemanticExtractor
from agent_context_os.graph_store import GraphStore
from agent_context_os.models import AskResult, DocumentChunk, ReplayRecord, ReplayStep
from agent_context_os.prompt_compiler import PromptCompiler
from agent_context_os.replay import ReplayStore
from agent_context_os.router import ModelRouter
from agent_context_os.tokenizer import count_tokens


class ContextOS:
    """Local-first semantic context SDK.

    ContextOS ingests text, extracts semantic facts, retrieves relevant context,
    compiles an optimized prompt, routes it to an LLM provider, and records a
    replay trail for every ask call.
    """

    def __init__(
        self,
        provider: str = "mock",
        model: str | None = None,
        token_budget: int = 1200,
        storage_dir: str | Path | None = None,
    ) -> None:
        self.provider = provider
        self.model = model
        self.token_budget = token_budget
        self.storage_dir = Path(storage_dir or ".contextos")
        self.storage_dir.mkdir(parents=True, exist_ok=True)

        self.graph_store = GraphStore()
        self.extractor = SemanticExtractor(provider=provider)
        self.optimizer = ContextOptimizer(token_budget=token_budget)
        self.compiler = PromptCompiler()
        self.router = ModelRouter(provider=provider, model=model)
        self.replays = ReplayStore()
        self.chunks: list[DocumentChunk] = []
        self._timeline: list[ReplayStep] = []

    def add_text(self, text: str, source: str = "inline") -> list:
        """Add text to memory and extract semantic graph facts."""
        clean_text = text.strip()
        if not clean_text:
            return []

        chunk = DocumentChunk(id=str(uuid4()), text=clean_text, source=source)
        self.chunks.append(chunk)
        self._timeline.append(ReplayStep(event="uploaded text", detail=f"Added text from {source}."))

        facts = self.extractor.extract(clean_text)
        self.graph_store.add_facts(facts)
        self._timeline.append(
            ReplayStep(event="graph extracted", detail=f"Extracted {len(facts)} semantic facts.")
        )
        return facts

    def add_file(self, path: str | Path) -> list:
        """Read a UTF-8 text-like file and add it to memory."""
        file_path = Path(path)
        text = file_path.read_text(encoding="utf-8")
        return self.add_text(text, source=str(file_path))

    def ask(self, query: str, token_budget: int | None = None) -> AskResult:
        """Ask a question using optimized graph and chunk context."""
        query_id = str(uuid4())
        started = datetime.now(timezone.utc)
        timeline = list(self._timeline)

        graph_facts = self.graph_store.search(query)
        timeline.append(
            ReplayStep(event="context retrieved", detail=f"Retrieved {len(graph_facts)} graph facts.")
        )

        optimization = self.optimizer.optimize(
            query=query,
            chunks=self.chunks,
            graph_facts=graph_facts,
            token_budget=token_budget or self.token_budget,
        )
        timeline.append(
            ReplayStep(
                event="context optimized",
                detail=(
                    f"Reduced {optimization.original_tokens} tokens to "
                    f"{optimization.optimized_tokens} tokens."
                ),
            )
        )

        prompt = self.compiler.compile(query=query, optimized_context=optimization.context)
        timeline.append(ReplayStep(event="prompt compiled", detail="Structured prompt created."))

        response = self.router.complete(prompt)
        timeline.append(
            ReplayStep(
                event="model called",
                detail=f"Provider={response.provider}, model={response.model}.",
            )
        )
        timeline.append(ReplayStep(event="response generated", detail="LLM response returned."))

        replay = ReplayRecord(
            query_id=query_id,
            original_token_count=optimization.original_tokens,
            optimized_token_count=optimization.optimized_tokens,
            tokens_saved_percent=optimization.tokens_saved_percent,
            semantic_facts_retained=optimization.semantic_facts_retained,
            chunks_retained=optimization.chunks_retained,
            removed_context_summary=optimization.removed_context_summary,
            final_prompt=prompt,
            provider=response.provider,
            model=response.model,
            timestamp=started,
            timeline=timeline,
        )
        self.replays.add(replay)

        return AskResult(
            query_id=query_id,
            answer=response.text,
            semantic_graph=self.graph_store.to_dict(),
            tokens_saved_percent=optimization.tokens_saved_percent,
            original_tokens=optimization.original_tokens,
            optimized_tokens=optimization.optimized_tokens,
            replay=replay,
        )

    def get_replay(self, query_id: str) -> ReplayRecord | None:
        return self.replays.get(query_id)

    def list_replays(self) -> list[ReplayRecord]:
        return self.replays.list()

    def export(self, output_dir: str | Path = "contextos_export") -> dict[str, Path]:
        """Export graph, memory, and replay data as JSON files."""
        output = Path(output_dir)
        output.mkdir(parents=True, exist_ok=True)

        graph_path = output / "semantic_graph.json"
        memory_path = output / "memory.json"
        replay_path = output / "replay.json"

        self.graph_store.export_json(graph_path)
        memory_path.write_text(
            self._json_dump({"chunks": [chunk.model_dump() for chunk in self.chunks]}),
            encoding="utf-8",
        )
        self.replays.export_json(replay_path)

        return {
            "semantic_graph": graph_path,
            "memory": memory_path,
            "replay": replay_path,
        }

    @staticmethod
    def _json_dump(data: Any) -> str:
        import json

        return json.dumps(data, indent=2, default=str)

    @property
    def semantic_graph(self) -> dict:
        return self.graph_store.to_dict()

    @property
    def memory(self) -> list[DocumentChunk]:
        return list(self.chunks)

    def token_count(self, text: str) -> int:
        return count_tokens(text)
