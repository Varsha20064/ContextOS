from __future__ import annotations

from agent_context_os.models import LLMResponse


class ModelRouter:
    """Route prompts to OpenAI, FastRouter, or local mock mode."""

    def __init__(self, provider: str = "mock", model: str | None = None) -> None:
        self.provider = provider
        self.model = model

    def complete(self, prompt: str) -> LLMResponse:
        if self.provider == "openai":
            from agent_context_os.llms.openai_client import OpenAIClient

            return OpenAIClient(model=self.model).complete(prompt)
        if self.provider == "fastrouter":
            from agent_context_os.llms.fastrouter_client import FastRouterClient

            return FastRouterClient(model=self.model).complete(prompt)
        from agent_context_os.llms.mock_client import MockClient

        return MockClient(model=self.model).complete(prompt)
