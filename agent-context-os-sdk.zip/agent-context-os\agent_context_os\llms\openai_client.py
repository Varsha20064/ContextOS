from __future__ import annotations

import os

from dotenv import load_dotenv

from agent_context_os.models import LLMResponse

load_dotenv()


class OpenAIClient:
    def __init__(self, model: str | None = None) -> None:
        self.model = model or os.getenv("OPENAI_MODEL", "gpt-4o-mini")
        self.client = None
        if os.getenv("OPENAI_API_KEY"):
            from openai import OpenAI

            self.client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

    def complete(self, prompt: str) -> LLMResponse:
        if self.client is None:
            return LLMResponse(
                text="OpenAI API key is missing. Set OPENAI_API_KEY or use provider='mock'.",
                provider="openai",
                model=self.model,
            )
        response = self.client.chat.completions.create(
            model=self.model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
        )
        return LLMResponse(
            text=response.choices[0].message.content or "",
            provider="openai",
            model=self.model,
            raw=response.model_dump(),
        )
