"""Example: use the official OpenAI SDK against ContextOS Proxy.

This demonstrates the core value proposition: developers change only
``base_url`` (and use a placeholder ``api_key``) and get semantic graph
retrieval, prompt optimization, and model routing automatically.

Run the proxy first:

    uvicorn contextos_proxy.server:app --host 0.0.0.0 --port 8787

Then (optionally after running examples/ingest_context.py):

    python examples/openai_client_example.py
"""

from openai import OpenAI

client = OpenAI(
    api_key="contextos-local-key",
    base_url="http://localhost:8787/v1",
)


def main() -> None:
    """Send a chat completion request through the proxy."""
    response = client.chat.completions.create(
        model="auto",
        messages=[{"role": "user", "content": "Explain OrbitGuard architecture"}],
    )
    print("Response:")
    print(response.choices[0].message.content)
    print("\nUsage:", response.usage)


if __name__ == "__main__":
    main()
