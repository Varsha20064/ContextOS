"""Example: ingest semantic context into a running ContextOS Proxy.

Run the proxy first:

    uvicorn contextos_proxy.server:app --host 0.0.0.0 --port 8787

Then run this script:

    python examples/ingest_context.py
"""

import httpx

PROXY_URL = "http://localhost:8787/v1/context/ingest"

SAMPLE_TEXT = """
OrbitGuard is a kind of satellite monitoring platform.
OrbitGuard depends on the TelemetryIngestor service.
TelemetryIngestor uses Apache Kafka for streaming.
OrbitGuard stores telemetry data in TimescaleDB.
The AlertEngine monitors anomaly scores from OrbitGuard.
AlertEngine sends notifications to the OpsDashboard.
OpsDashboard is part of the OrbitGuard control plane.
"""


def main() -> None:
    """Send a sample ingestion request to the proxy."""
    payload = {
        "text": SAMPLE_TEXT,
        "source": "orbitguard_architecture_notes",
        "metadata": {"author": "platform-team", "category": "architecture"},
    }
    response = httpx.post(PROXY_URL, json=payload, timeout=30.0)
    response.raise_for_status()
    print("Ingestion result:")
    print(response.json())


if __name__ == "__main__":
    main()
