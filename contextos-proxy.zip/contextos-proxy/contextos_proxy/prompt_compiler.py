"""Compiles a structured prompt from a user query and semantic graph facts."""

from __future__ import annotations

from typing import List, Optional

from contextos_proxy.semantic_graph import Fact


def compile_prompt(
    user_query: str,
    facts: List[Fact],
    goal: Optional[str] = None,
    constraints: Optional[str] = None,
    output_format: Optional[str] = None,
) -> str:
    """Build a structured prompt combining the user query and graph context.

    Args:
        user_query: The raw query/instruction from the end user.
        facts: Relevant, already-optimized semantic graph facts.
        goal: Optional explicit goal statement. Defaults to a generic
            "answer the user's query accurately" goal.
        constraints: Optional constraints text. Defaults to a generic
            accuracy/conciseness constraint.
        output_format: Optional desired output format description.
            Defaults to "Respond naturally in clear, well-structured text."

    Returns:
        A single string prompt with explicit Goal / User Query /
        Relevant Semantic Graph Context / Constraints / Output Format
        sections, ready to be sent to the model.
    """
    goal_text = goal or "Answer the user's query accurately using any relevant context provided below."
    constraints_text = (
        constraints
        or "Be accurate and concise. Only use the semantic graph context if it is relevant; "
        "ignore it otherwise. Do not invent facts that contradict the provided context."
    )
    output_format_text = output_format or "Respond naturally in clear, well-structured text."

    if facts:
        context_lines = "\n".join(f"- {fact.as_sentence()}" for fact in facts)
    else:
        context_lines = "(no relevant semantic graph facts found)"

    return (
        f"Goal:\n{goal_text}\n\n"
        f"User Query:\n{user_query}\n\n"
        f"Relevant Semantic Graph Context:\n{context_lines}\n\n"
        f"Constraints:\n{constraints_text}\n\n"
        f"Output Format:\n{output_format_text}"
    )
