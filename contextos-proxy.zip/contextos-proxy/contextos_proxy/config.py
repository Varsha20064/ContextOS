"""Configuration management for ContextOS Proxy.

All configuration is sourced from environment variables (optionally
loaded from a local .env file via python-dotenv). No API keys or
secrets are ever hardcoded.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Optional

try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:  # pragma: no cover - dotenv is a declared dependency
    pass


def _get_int(name: str, default: int) -> int:
    """Read an integer environment variable, falling back to a default."""
    raw = os.getenv(name)
    if raw is None or raw.strip() == "":
        return default
    try:
        return int(raw)
    except ValueError:
        return default


@dataclass(frozen=True)
class Settings:
    """Runtime settings for the proxy, loaded once at process startup."""

    openai_api_key: Optional[str] = field(default=None)
    fastrouter_api_key: Optional[str] = field(default=None)
    fastrouter_base_url: str = field(default="https://go.fastrouter.ai/api/v1")
    default_provider: str = field(default="mock")
    default_model: str = field(default="gpt-4o-mini")
    token_budget: int = field(default=2000)
    host: str = field(default="0.0.0.0")
    port: int = field(default=8787)
    storage_dir: str = field(default=".contextos_data")

    @property
    def has_openai(self) -> bool:
        """Whether a usable OpenAI API key is configured."""
        return bool(self.openai_api_key)

    @property
    def has_fastrouter(self) -> bool:
        """Whether a usable FastRouter API key is configured."""
        return bool(self.fastrouter_api_key)

    @property
    def is_mock_mode(self) -> bool:
        """True when neither real provider has credentials configured."""
        return not self.has_openai and not self.has_fastrouter


def load_settings() -> Settings:
    """Build a :class:`Settings` instance from the current environment."""
    return Settings(
        openai_api_key=os.getenv("OPENAI_API_KEY") or None,
        fastrouter_api_key=os.getenv("FASTROUTER_API_KEY") or None,
        fastrouter_base_url=os.getenv(
            "FASTROUTER_BASE_URL", "https://go.fastrouter.ai/api/v1"
        ),
        default_provider=os.getenv("DEFAULT_PROVIDER", "mock").lower(),
        default_model=os.getenv("DEFAULT_MODEL", "gpt-4o-mini"),
        token_budget=_get_int("TOKEN_BUDGET", 2000),
        host=os.getenv("CONTEXTOS_HOST", "0.0.0.0"),
        port=_get_int("CONTEXTOS_PORT", 8787),
        storage_dir=os.getenv("CONTEXTOS_STORAGE_DIR", ".contextos_data"),
    )


# Module-level singleton, re-read lazily so tests can monkeypatch env vars
# and call `reload_settings()`.
settings = load_settings()


def reload_settings() -> Settings:
    """Reload settings from the environment and update the module singleton.

    Useful in tests where environment variables are changed at runtime.
    """
    global settings
    settings = load_settings()
    return settings
