"""Persistence layer for the semantic graph.

Persists the graph to a JSON file on disk so that ingested facts survive
process restarts. Storage is deliberately simple (no external database)
to keep ContextOS Proxy local-first and dependency-light.
"""

from __future__ import annotations

import json
import os
import threading
from typing import Optional

from contextos_proxy.semantic_graph import SemanticGraph


class GraphStore:
    """File-backed persistence wrapper around a :class:`SemanticGraph`."""

    def __init__(self, storage_dir: str) -> None:
        self._storage_dir = storage_dir
        self._path = os.path.join(storage_dir, "graph.json")
        self._lock = threading.Lock()
        self.graph = SemanticGraph()
        os.makedirs(self._storage_dir, exist_ok=True)
        self._load()

    def _load(self) -> None:
        """Load graph state from disk if a previous snapshot exists."""
        if not os.path.exists(self._path):
            return
        try:
            with open(self._path, "r", encoding="utf-8") as fh:
                payload = json.load(fh)
            self.graph.load_json(payload)
        except (json.JSONDecodeError, OSError):
            # Corrupt or unreadable snapshot - start fresh rather than crash.
            self.graph = SemanticGraph()

    def save(self) -> None:
        """Persist the current graph state to disk."""
        with self._lock:
            payload = self.graph.to_json()
            tmp_path = self._path + ".tmp"
            with open(tmp_path, "w", encoding="utf-8") as fh:
                json.dump(payload, fh, indent=2)
            os.replace(tmp_path, self._path)

    @property
    def path(self) -> str:
        """Filesystem path of the persisted graph snapshot."""
        return self._path
