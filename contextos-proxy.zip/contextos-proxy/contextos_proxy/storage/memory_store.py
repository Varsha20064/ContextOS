"""Persistence layer for request replay/trace records.

Stores one JSON record per request in-memory (bounded ring buffer) and
mirrors them to a JSON-lines file on disk so traces survive restarts.
"""

from __future__ import annotations

import json
import os
import threading
from collections import OrderedDict
from typing import Any, Dict, List, Optional


class MemoryStore:
    """Bounded, file-backed store for request replay records."""

    def __init__(self, storage_dir: str, max_records: int = 1000) -> None:
        self._storage_dir = storage_dir
        self._path = os.path.join(storage_dir, "replay.jsonl")
        self._max_records = max_records
        self._lock = threading.Lock()
        self._records: "OrderedDict[str, Dict[str, Any]]" = OrderedDict()
        os.makedirs(self._storage_dir, exist_ok=True)
        self._load()

    def _load(self) -> None:
        """Load existing replay records from the JSON-lines file."""
        if not os.path.exists(self._path):
            return
        try:
            with open(self._path, "r", encoding="utf-8") as fh:
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        record = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    request_id = record.get("request_id")
                    if request_id:
                        self._records[request_id] = record
            while len(self._records) > self._max_records:
                self._records.popitem(last=False)
        except OSError:
            pass

    def add(self, record: Dict[str, Any]) -> None:
        """Add a new replay record, appending it to disk and memory."""
        with self._lock:
            request_id = record["request_id"]
            self._records[request_id] = record
            if len(self._records) > self._max_records:
                self._records.popitem(last=False)
            with open(self._path, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(record) + "\n")

    def get(self, request_id: str) -> Optional[Dict[str, Any]]:
        """Fetch a single replay record by its request id."""
        return self._records.get(request_id)

    def list_all(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Return the most recent ``limit`` replay records, newest first."""
        items = list(self._records.values())
        return list(reversed(items))[:limit]

    def count(self) -> int:
        """Total number of replay records currently held in memory."""
        return len(self._records)
