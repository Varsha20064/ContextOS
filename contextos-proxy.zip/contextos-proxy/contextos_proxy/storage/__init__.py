"""Local storage backends for ContextOS Proxy."""
