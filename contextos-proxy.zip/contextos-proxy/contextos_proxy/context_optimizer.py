"""Context optimization: dedupe, compress, and budget semantic facts."""

from __future__ import annotations

from dataclasses import dataclass
from typing import List

from contextos_proxy.semantic_graph import Fact
from contextos_proxy.token_meter import count_tokens, savings_percent


@dataclass
class OptimizationResult:
    """Result of optimizing a set of candidate facts against a token budget."""

    facts: List[Fact]
    original_tokens: int
    optimized_tokens: int
    tokens_saved_percent: float


def _dedupe_facts(facts: List[Fact]) -> List[Fact]:
    """Remove exact-duplicate facts, preserving first-seen order."""
    seen = set()
    deduped: List[Fact] = []
    for fact in facts:
        key = (fact.subject.lower(), fact.relation.lower(), fact.obj.lower())
        if key in seen:
            continue
        seen.add(key)
        deduped.append(fact)
    return deduped


def optimize_context(facts: List[Fact], token_budget: int) -> OptimizationResult:
    """Deduplicate and compress facts to fit within a token budget.

    The optimizer works in two stages:

    1. Deduplication - exact-duplicate ``subject/relation/object`` triples
       are collapsed to a single occurrence.
    2. Budgeting - facts are added to the final context (in their given
       relevance order) until adding the next fact would exceed
       ``token_budget`` tokens of rendered context text.

    Args:
        facts: Candidate facts, expected to already be sorted by
            relevance (most relevant first).
        token_budget: Maximum number of tokens the rendered fact context
            may occupy.

    Returns:
        An :class:`OptimizationResult` describing the retained facts and
        the token accounting before/after optimization.
    """
    deduped = _dedupe_facts(facts)

    original_text = "\n".join(f.as_sentence() for f in deduped)
    original_tokens = count_tokens(original_text)

    retained: List[Fact] = []
    running_tokens = 0
    for fact in deduped:
        sentence_tokens = count_tokens(fact.as_sentence())
        if running_tokens + sentence_tokens > token_budget:
            continue
        retained.append(fact)
        running_tokens += sentence_tokens

    optimized_text = "\n".join(f.as_sentence() for f in retained)
    optimized_tokens = count_tokens(optimized_text)

    return OptimizationResult(
        facts=retained,
        original_tokens=original_tokens,
        optimized_tokens=optimized_tokens,
        tokens_saved_percent=savings_percent(original_tokens, optimized_tokens),
    )
