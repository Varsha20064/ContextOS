"""Local semantic graph built on top of NetworkX.

Facts are stored as a directed multigraph where nodes are entities
(subjects/objects) and edges carry the relation name plus metadata
(source document, timestamp, etc.). This module also implements a
lightweight, dependency-free fact extractor that turns raw ingested
text into ``subject -> relation -> object`` triples.
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional

import networkx as nx


@dataclass(frozen=True)
class Fact:
    """A single semantic fact: subject -> relation -> object."""

    subject: str
    relation: str
    obj: str
    source: str = "unknown"
    confidence: float = 1.0
    timestamp: float = 0.0

    def as_sentence(self) -> str:
        """Render the fact as a compact natural-language-like sentence."""
        return f"{self.subject} {self.relation} {self.obj}".strip()

    def to_dict(self) -> Dict[str, Any]:
        """Serialize the fact to a plain dictionary."""
        return asdict(self)


_STOPWORDS = {
    "a",
    "an",
    "the",
    "is",
    "are",
    "was",
    "were",
    "be",
    "been",
    "being",
    "of",
    "in",
    "on",
    "at",
    "to",
    "for",
    "and",
    "or",
    "but",
    "with",
    "as",
    "by",
    "that",
    "this",
    "it",
    "its",
}

# Relation verbs/phrases recognized by the lightweight extractor.
_RELATION_PATTERNS = [
    r"is a kind of",
    r"is a type of",
    r"is part of",
    r"is responsible for",
    r"is composed of",
    r"is built on",
    r"is built using",
    r"depends on",
    r"consists of",
    r"connects to",
    r"communicates with",
    r"uses",
    r"calls",
    r"implements",
    r"extends",
    r"contains",
    r"includes",
    r"requires",
    r"manages",
    r"controls",
    r"monitors",
    r"stores",
    r"sends",
    r"receives",
    r"is",
    r"has",
    r"provides",
    r"supports",
    r"runs on",
    r"runs",
    r"handles",
]

_RELATION_REGEX = re.compile(
    r"^(?P<subject>.+?)\s+(?P<relation>"
    + "|".join(sorted(_RELATION_PATTERNS, key=len, reverse=True))
    + r")\s+(?P<object>.+)$",
    re.IGNORECASE,
)


def _split_sentences(text: str) -> List[str]:
    """Split text into trimmed, non-empty sentences."""
    raw_sentences = re.split(r"(?<=[.!?])\s+|\n+", text)
    return [s.strip().rstrip(".!?") for s in raw_sentences if s.strip()]


def extract_facts(text: str, source: str = "unknown") -> List[Fact]:
    """Extract ``subject -> relation -> object`` facts from raw text.

    This is a deterministic, regex/heuristic-based extractor designed to
    work fully offline without any external NLP model. It recognizes a
    fixed set of common relation verbs/phrases (e.g. "uses", "depends on",
    "is part of") and splits each sentence around the first occurrence of
    one of these relations.

    Args:
        text: Raw input text (e.g. documentation, notes, architecture
            descriptions).
        source: A label identifying where this text came from, stored on
            each extracted fact for traceability.

    Returns:
        A list of :class:`Fact` objects. Sentences that do not match any
        known relation pattern are skipped.
    """
    facts: List[Fact] = []
    now = time.time()
    for sentence in _split_sentences(text):
        match = _RELATION_REGEX.match(sentence)
        if not match:
            continue
        subject = match.group("subject").strip(" ,;:")
        relation = match.group("relation").strip().lower()
        obj = match.group("object").strip(" ,;:")
        if not subject or not obj:
            continue
        # Skip overly long "objects" that are likely not real facts but
        # leftover clause fragments (keeps the graph compact and useful).
        if len(obj.split()) > 20 or len(subject.split()) > 12:
            continue
        facts.append(
            Fact(
                subject=subject,
                relation=relation,
                obj=obj,
                source=source,
                confidence=1.0,
                timestamp=now,
            )
        )
    return facts


def _tokenize(text: str) -> List[str]:
    """Lowercase word tokenizer with stopword removal, used for search."""
    words = re.findall(r"[a-zA-Z0-9_]+", text.lower())
    return [w for w in words if w not in _STOPWORDS and len(w) > 1]


class SemanticGraph:
    """A directed multigraph of semantic facts with simple keyword search."""

    def __init__(self) -> None:
        self._graph = nx.MultiDiGraph()

    def add_fact(self, fact: Fact) -> None:
        """Add a single fact to the graph as an edge between two nodes."""
        self._graph.add_node(fact.subject)
        self._graph.add_node(fact.obj)
        self._graph.add_edge(
            fact.subject,
            fact.obj,
            relation=fact.relation,
            source=fact.source,
            confidence=fact.confidence,
            timestamp=fact.timestamp,
        )

    def add_facts(self, facts: List[Fact]) -> int:
        """Add multiple facts to the graph.

        Returns:
            The number of facts added.
        """
        for fact in facts:
            self.add_fact(fact)
        return len(facts)

    def all_facts(self) -> List[Fact]:
        """Return every fact currently stored in the graph."""
        result: List[Fact] = []
        for u, v, data in self._graph.edges(data=True):
            result.append(
                Fact(
                    subject=u,
                    relation=data.get("relation", "relates to"),
                    obj=v,
                    source=data.get("source", "unknown"),
                    confidence=data.get("confidence", 1.0),
                    timestamp=data.get("timestamp", 0.0),
                )
            )
        return result

    def search(self, query: str, limit: int = 20) -> List[Fact]:
        """Search for facts relevant to ``query`` using keyword overlap.

        Each fact is scored by how many query keywords appear in its
        subject, relation, or object text (case-insensitive substring
        match), plus a bonus when the query keyword exactly matches a
        node name. Results are returned sorted by descending score.

        Args:
            query: The free-text user query.
            limit: Maximum number of facts to return.

        Returns:
            A list of the most relevant :class:`Fact` objects, possibly
            empty if nothing matches.
        """
        keywords = set(_tokenize(query))
        if not keywords:
            return []

        node_names = {n.lower(): n for n in self._graph.nodes}
        candidate_nodes = set()
        for keyword in keywords:
            for lower_name, original_name in node_names.items():
                if keyword in lower_name:
                    candidate_nodes.add(original_name)

        scored: List[Any] = []
        for u, v, data in self._graph.edges(data=True):
            sentence = f"{u} {data.get('relation', '')} {v}".lower()
            score = sum(1 for kw in keywords if kw in sentence)
            if u in candidate_nodes or v in candidate_nodes:
                score += 2
            if score > 0:
                fact = Fact(
                    subject=u,
                    relation=data.get("relation", "relates to"),
                    obj=v,
                    source=data.get("source", "unknown"),
                    confidence=data.get("confidence", 1.0),
                    timestamp=data.get("timestamp", 0.0),
                )
                scored.append((score, fact))

        scored.sort(key=lambda pair: pair[0], reverse=True)
        return [fact for _, fact in scored[:limit]]

    def node_count(self) -> int:
        """Number of distinct entities (nodes) in the graph."""
        return self._graph.number_of_nodes()

    def edge_count(self) -> int:
        """Number of facts (edges) in the graph."""
        return self._graph.number_of_edges()

    def to_json(self) -> Dict[str, Any]:
        """Export the full graph as a JSON-serializable dictionary."""
        nodes = list(self._graph.nodes)
        edges = [
            {
                "subject": u,
                "object": v,
                "relation": data.get("relation"),
                "source": data.get("source"),
                "confidence": data.get("confidence"),
                "timestamp": data.get("timestamp"),
            }
            for u, v, data in self._graph.edges(data=True)
        ]
        return {"nodes": nodes, "edges": edges}

    def load_json(self, payload: Dict[str, Any]) -> None:
        """Load graph state previously produced by :meth:`to_json`."""
        self._graph = nx.MultiDiGraph()
        for edge in payload.get("edges", []):
            self.add_fact(
                Fact(
                    subject=edge["subject"],
                    relation=edge.get("relation", "relates to"),
                    obj=edge["object"],
                    source=edge.get("source", "unknown"),
                    confidence=edge.get("confidence", 1.0),
                    timestamp=edge.get("timestamp", 0.0),
                )
            )

    def clear(self) -> None:
        """Remove all facts from the graph."""
        self._graph = nx.MultiDiGraph()
