"""ContextOS Proxy.

A local-first, OpenAI-compatible semantic context gateway.

ContextOS Proxy sits between any OpenAI-SDK-compatible application and
LLM providers (OpenAI, FastRouter, or a local Mock provider). It
intercepts chat completion requests, retrieves relevant facts from a
local semantic graph, compresses/optimizes the resulting context to
fit a token budget, compiles a structured prompt, routes the request
to the best available model/provider, and returns an OpenAI-compatible
response.

It is NOT a chatbot and NOT a SaaS dashboard - it is middleware.
"""

__version__ = "0.1.0"
