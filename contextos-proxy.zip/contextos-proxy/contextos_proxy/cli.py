"""Command-line interface for ContextOS Proxy.

Installed as the ``contextos-proxy`` console script.
"""

from __future__ import annotations

import json
import sys

import click

from contextos_proxy.config import settings
from contextos_proxy.proxy import ContextIngestRequest, ContextOSProxy
from contextos_proxy.storage.graph_store import GraphStore
from contextos_proxy.storage.memory_store import MemoryStore


@click.group()
def cli() -> None:
    """ContextOS Proxy - local-first OpenAI-compatible semantic context gateway."""


@cli.command()
@click.option("--host", default=None, help="Bind host (default from settings/env).")
@click.option("--port", default=None, type=int, help="Bind port (default from settings/env).")
@click.option("--reload", is_flag=True, default=False, help="Enable auto-reload for development.")
def serve(host: str, port: int, reload: bool) -> None:
    """Run the ContextOS Proxy server with uvicorn."""
    import uvicorn

    uvicorn.run(
        "contextos_proxy.server:app",
        host=host or settings.host,
        port=port or settings.port,
        reload=reload,
    )


@cli.command()
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--source", default=None, help="Source label for ingested facts (default: filename).")
def ingest(file: str, source: str) -> None:
    """Ingest a text FILE into the local semantic graph."""
    with open(file, "r", encoding="utf-8") as fh:
        text = fh.read()

    graph_store = GraphStore(settings.storage_dir)
    memory_store = MemoryStore(settings.storage_dir)
    proxy = ContextOSProxy(
        settings=settings,
        graph=graph_store.graph,
        memory_store=memory_store,
        on_graph_change=graph_store.save,
    )

    result = proxy.ingest(ContextIngestRequest(text=text, source=source or file))
    click.echo(f"Extracted {result.facts_extracted} facts from '{file}':")
    for fact in result.facts:
        click.echo(f"  - {fact}")
    click.echo(
        f"Graph now has {result.graph_nodes} nodes and {result.graph_edges} edges."
    )


@cli.command()
def graph() -> None:
    """Print the current semantic graph as JSON."""
    graph_store = GraphStore(settings.storage_dir)
    click.echo(json.dumps(graph_store.graph.to_json(), indent=2))


@cli.command()
def stats() -> None:
    """Print summary statistics about the graph and request history."""
    graph_store = GraphStore(settings.storage_dir)
    memory_store = MemoryStore(settings.storage_dir)
    records = memory_store.list_all(limit=200)
    avg_savings = (
        round(sum(r.get("tokens_saved_percent", 0.0) for r in records) / len(records), 2)
        if records
        else 0.0
    )
    payload = {
        "graph_nodes": graph_store.graph.node_count(),
        "graph_edges": graph_store.graph.edge_count(),
        "total_requests_served": memory_store.count(),
        "average_tokens_saved_percent_recent": avg_savings,
        "mode": "mock" if settings.is_mock_mode else "live",
    }
    click.echo(json.dumps(payload, indent=2))


def main() -> None:
    """Entrypoint used by the ``contextos-proxy`` console script."""
    cli(prog_name="contextos-proxy")


if __name__ == "__main__":
    main()
