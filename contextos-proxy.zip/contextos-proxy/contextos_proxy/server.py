"""FastAPI application exposing the ContextOS Proxy HTTP API."""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse

from contextos_proxy.config import settings as default_settings
from contextos_proxy.proxy import (
    ChatCompletionRequest,
    ChatCompletionResponse,
    ContextIngestRequest,
    ContextIngestResponse,
    ContextOSProxy,
)
from contextos_proxy.providers import ProviderError
from contextos_proxy.storage.graph_store import GraphStore
from contextos_proxy.storage.memory_store import MemoryStore

app = FastAPI(
    title="ContextOS Proxy",
    description=(
        "Local-first, OpenAI-compatible semantic context gateway. "
        "Not a chatbot - a middleware proxy for AI context."
    ),
    version="0.1.0",
)

_settings = default_settings
_graph_store = GraphStore(_settings.storage_dir)
_memory_store = MemoryStore(_settings.storage_dir)
_proxy = ContextOSProxy(
    settings=_settings,
    graph=_graph_store.graph,
    memory_store=_memory_store,
    on_graph_change=_graph_store.save,
)

_start_time = time.time()


@app.get("/health")
def health() -> Dict[str, Any]:
    """Liveness/readiness probe and basic runtime info."""
    return {
        "status": "ok",
        "mode": "mock" if _settings.is_mock_mode else "live",
        "default_provider": _settings.default_provider,
        "default_model": _settings.default_model,
        "uptime_seconds": round(time.time() - _start_time, 2),
    }


@app.post("/v1/chat/completions", response_model=ChatCompletionResponse)
async def chat_completions(request: ChatCompletionRequest) -> ChatCompletionResponse:
    """OpenAI-compatible chat completions endpoint.

    Accepts a standard OpenAI chat completion request body and returns an
    OpenAI-compatible response, after enriching the prompt with semantic
    graph context, optimizing token usage, and routing to the best
    available model/provider.
    """
    if not request.messages:
        raise HTTPException(status_code=400, detail="messages must not be empty")
    try:
        return await _proxy.chat_completion(request)
    except ProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/v1/context/ingest", response_model=ContextIngestResponse)
def context_ingest(request: ContextIngestRequest) -> ContextIngestResponse:
    """Ingest raw text, extracting and storing semantic graph facts."""
    if not request.text or not request.text.strip():
        raise HTTPException(status_code=400, detail="text must not be empty")
    return _proxy.ingest(request)


@app.get("/v1/replay/{request_id}")
def get_replay(request_id: str) -> Dict[str, Any]:
    """Fetch the full trace for a single previously-served request."""
    record = _memory_store.get(request_id)
    if record is None:
        raise HTTPException(status_code=404, detail=f"No replay found for {request_id}")
    return record


@app.get("/v1/replay")
def list_replay(limit: int = 50) -> Dict[str, Any]:
    """List the most recent request traces, newest first."""
    return {"count": _memory_store.count(), "records": _memory_store.list_all(limit=limit)}


@app.get("/v1/stats")
def stats() -> Dict[str, Any]:
    """Aggregate statistics about graph size and recent token savings."""
    records = _memory_store.list_all(limit=200)
    if records:
        avg_savings = round(
            sum(r.get("tokens_saved_percent", 0.0) for r in records) / len(records), 2
        )
    else:
        avg_savings = 0.0

    provider_counts: Dict[str, int] = {}
    for r in records:
        provider_counts[r["selected_provider"]] = (
            provider_counts.get(r["selected_provider"], 0) + 1
        )

    return {
        "graph_nodes": _graph_store.graph.node_count(),
        "graph_edges": _graph_store.graph.edge_count(),
        "total_requests_served": _memory_store.count(),
        "average_tokens_saved_percent_recent": avg_savings,
        "provider_usage_recent": provider_counts,
        "mode": "mock" if _settings.is_mock_mode else "live",
    }


@app.get("/v1/graph")
def get_graph() -> Dict[str, Any]:
    """Export the full semantic graph as JSON (nodes and edges)."""
    return _graph_store.graph.to_json()


@app.exception_handler(Exception)
async def unhandled_exception_handler(request, exc: Exception) -> JSONResponse:
    """Ensure unexpected errors still return a JSON body instead of a crash."""
    return JSONResponse(
        status_code=500,
        content={"error": {"message": str(exc), "type": exc.__class__.__name__}},
    )
