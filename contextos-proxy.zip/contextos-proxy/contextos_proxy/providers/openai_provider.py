"""OpenAI provider backend.

Calls the OpenAI Chat Completions API directly over HTTP using
``httpx``, so the dependency surface stays small and predictable.
"""

from __future__ import annotations

from typing import Dict, List, Optional

import httpx

from contextos_proxy.providers import ProviderError, ProviderResponse

_OPENAI_CHAT_URL = "https://api.openai.com/v1/chat/completions"


class OpenAIProvider:
    """Provider backend that forwards requests to the OpenAI API."""

    name = "openai"

    def __init__(self, api_key: str, timeout: float = 60.0) -> None:
        if not api_key:
            raise ValueError("OpenAIProvider requires a non-empty api_key")
        self._api_key = api_key
        self._timeout = timeout

    async def complete(
        self, model: str, messages: List[Dict[str, str]], **kwargs
    ) -> ProviderResponse:
        """Send a chat completion request to OpenAI.

        Args:
            model: OpenAI model name (e.g. ``gpt-4o-mini``).
            messages: OpenAI-style chat messages.
            **kwargs: Additional OpenAI chat-completion parameters such as
                ``temperature`` or ``max_tokens``.

        Returns:
            A normalized :class:`ProviderResponse`.

        Raises:
            ProviderError: If the OpenAI API returns an error response or
                the request otherwise fails.
        """
        payload: Dict[str, object] = {"model": model, "messages": messages}
        for key in ("temperature", "max_tokens", "top_p", "n", "stop"):
            if key in kwargs and kwargs[key] is not None:
                payload[key] = kwargs[key]

        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }

        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                response = await client.post(
                    _OPENAI_CHAT_URL, json=payload, headers=headers
                )
        except httpx.HTTPError as exc:
            raise ProviderError(f"OpenAI request failed: {exc}") from exc

        if response.status_code >= 400:
            raise ProviderError(
                f"OpenAI API error ({response.status_code}): {response.text}"
            )

        data = response.json()
        try:
            choice = data["choices"][0]
            content = choice["message"]["content"]
            finish_reason = choice.get("finish_reason", "stop")
            usage = data.get("usage", {})
        except (KeyError, IndexError) as exc:
            raise ProviderError(f"Unexpected OpenAI response shape: {data}") from exc

        return ProviderResponse(
            content=content,
            model=data.get("model", model),
            provider=self.name,
            prompt_tokens=usage.get("prompt_tokens", 0),
            completion_tokens=usage.get("completion_tokens", 0),
            finish_reason=finish_reason,
            raw=data,
        )
