"""FastRouter provider backend.

FastRouter exposes an OpenAI-compatible Chat Completions API, so this
provider mirrors :class:`OpenAIProvider` but targets a configurable
base URL.
"""

from __future__ import annotations

from typing import Dict, List

import httpx

from contextos_proxy.providers import ProviderError, ProviderResponse


class FastRouterProvider:
    """Provider backend that forwards requests to FastRouter."""

    name = "fastrouter"

    def __init__(self, api_key: str, base_url: str, timeout: float = 60.0) -> None:
        if not api_key:
            raise ValueError("FastRouterProvider requires a non-empty api_key")
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout

    async def complete(
        self, model: str, messages: List[Dict[str, str]], **kwargs
    ) -> ProviderResponse:
        """Send a chat completion request to FastRouter.

        Args:
            model: Model identifier as understood by FastRouter.
            messages: OpenAI-style chat messages.
            **kwargs: Additional chat-completion parameters.

        Returns:
            A normalized :class:`ProviderResponse`.

        Raises:
            ProviderError: If FastRouter returns an error or the request
                otherwise fails.
        """
        url = f"{self._base_url}/chat/completions"
        payload: Dict[str, object] = {"model": model, "messages": messages}
        for key in ("temperature", "max_tokens", "top_p", "n", "stop"):
            if key in kwargs and kwargs[key] is not None:
                payload[key] = kwargs[key]

        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }

        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                response = await client.post(url, json=payload, headers=headers)
        except httpx.HTTPError as exc:
            raise ProviderError(f"FastRouter request failed: {exc}") from exc

        if response.status_code >= 400:
            raise ProviderError(
                f"FastRouter API error ({response.status_code}): {response.text}"
            )

        data = response.json()
        try:
            choice = data["choices"][0]
            content = choice["message"]["content"]
            finish_reason = choice.get("finish_reason", "stop")
            usage = data.get("usage", {})
        except (KeyError, IndexError) as exc:
            raise ProviderError(
                f"Unexpected FastRouter response shape: {data}"
            ) from exc

        return ProviderResponse(
            content=content,
            model=data.get("model", model),
            provider=self.name,
            prompt_tokens=usage.get("prompt_tokens", 0),
            completion_tokens=usage.get("completion_tokens", 0),
            finish_reason=finish_reason,
            raw=data,
        )
