"""LLM provider backends used by the model router.

Each provider implements a uniform :meth:`complete` coroutine that takes
a model name and a list of OpenAI-style chat messages, and returns a
:class:`ProviderResponse` with the completion text and usage stats.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List


@dataclass
class ProviderResponse:
    """Normalized response returned by any provider backend."""

    content: str
    model: str
    provider: str
    prompt_tokens: int
    completion_tokens: int
    finish_reason: str = "stop"
    raw: Dict[str, Any] = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self.raw is None:
            self.raw = {}


class ProviderError(RuntimeError):
    """Raised when a provider backend fails to produce a completion."""
