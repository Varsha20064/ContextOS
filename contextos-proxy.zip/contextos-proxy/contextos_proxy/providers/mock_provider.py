"""Mock provider used when no real API keys are configured.

Produces deterministic, valid OpenAI-compatible completion text so the
whole proxy pipeline (ingestion, optimization, routing, replay) can be
exercised fully offline and in tests/CI without network access.
"""

from __future__ import annotations

from typing import Dict, List

from contextos_proxy.providers import ProviderResponse
from contextos_proxy.token_meter import count_tokens


class MockProvider:
    """Deterministic offline provider for local development and tests."""

    name = "mock"

    async def complete(
        self, model: str, messages: List[Dict[str, str]], **kwargs
    ) -> ProviderResponse:
        """Generate a deterministic mock completion.

        Args:
            model: The (mock) model name requested.
            messages: OpenAI-style chat messages. The last user message's
                content is echoed back as part of the mock response.

        Returns:
            A :class:`ProviderResponse` with synthetic content.
        """
        last_user_content = ""
        for message in reversed(messages):
            if message.get("role") == "user":
                last_user_content = message.get("content", "")
                break

        prompt_tokens = sum(count_tokens(m.get("content", "")) for m in messages)
        preview = last_user_content.strip().splitlines()[-1] if last_user_content else ""
        content = (
            "[mock-response] ContextOS Proxy is running in mock mode "
            "(no OPENAI_API_KEY or FASTROUTER_API_KEY configured). "
            f"Here is a simulated answer based on your compiled prompt. "
            f"Detected query tail: \"{preview[:200]}\""
        )
        completion_tokens = count_tokens(content)

        return ProviderResponse(
            content=content,
            model=model,
            provider=self.name,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            finish_reason="stop",
            raw={"mock": True},
        )
