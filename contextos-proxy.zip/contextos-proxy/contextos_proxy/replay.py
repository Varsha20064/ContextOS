"""Replay/trace record schema and helpers."""

from __future__ import annotations

import time
import uuid
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from contextos_proxy.semantic_graph import Fact


class ReplayRecord(BaseModel):
    """A full trace of a single ``/v1/chat/completions`` request."""

    request_id: str
    original_prompt: str
    optimized_prompt: str
    semantic_facts_used: List[str] = Field(default_factory=list)
    original_tokens: int
    optimized_tokens: int
    tokens_saved_percent: float
    selected_provider: str
    selected_model: str
    timestamp: float
    response_preview: str


def new_request_id() -> str:
    """Generate a unique request id, prefixed for easy recognition."""
    return f"req_{uuid.uuid4().hex[:24]}"


def build_replay_record(
    request_id: str,
    original_prompt: str,
    optimized_prompt: str,
    facts: List[Fact],
    original_tokens: int,
    optimized_tokens: int,
    tokens_saved_percent: float,
    selected_provider: str,
    selected_model: str,
    response_text: str,
) -> ReplayRecord:
    """Construct a :class:`ReplayRecord` from pipeline outputs.

    Args:
        request_id: Unique id for this request.
        original_prompt: The raw user prompt before optimization.
        optimized_prompt: The final compiled prompt sent to the provider.
        facts: The semantic facts retained after optimization.
        original_tokens: Token count of the unoptimized context.
        optimized_tokens: Token count of the optimized context.
        tokens_saved_percent: Percentage of tokens saved by optimization.
        selected_provider: Name of the provider used to serve the request.
        selected_model: Name of the model used to serve the request.
        response_text: The full text of the model's response.

    Returns:
        A populated :class:`ReplayRecord`.
    """
    preview = response_text.strip().replace("\n", " ")
    if len(preview) > 240:
        preview = preview[:240] + "..."
    return ReplayRecord(
        request_id=request_id,
        original_prompt=original_prompt,
        optimized_prompt=optimized_prompt,
        semantic_facts_used=[f.as_sentence() for f in facts],
        original_tokens=original_tokens,
        optimized_tokens=optimized_tokens,
        tokens_saved_percent=tokens_saved_percent,
        selected_provider=selected_provider,
        selected_model=selected_model,
        timestamp=time.time(),
        response_preview=preview,
    )
