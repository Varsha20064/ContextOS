"""Model routing: picks a provider + model for a given request.

When the client requests ``model="auto"``, the router inspects the user
query to classify the task (simple summary vs. code/reasoning vs.
general) and picks an appropriate model, then chooses a provider based
on what credentials are configured.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional

from contextos_proxy.config import Settings
from contextos_proxy.providers import ProviderResponse
from contextos_proxy.providers.fastrouter_provider import FastRouterProvider
from contextos_proxy.providers.mock_provider import MockProvider
from contextos_proxy.providers.openai_provider import OpenAIProvider

_CODE_HINTS = re.compile(
    r"\b(code|function|bug|stack ?trace|exception|refactor|algorithm|"
    r"regex|sql|api|class|compile|debug|architecture|design pattern|"
    r"complexity|implement|reasoning|prove|derive|optimi[sz]e)\b",
    re.IGNORECASE,
)
_SUMMARY_HINTS = re.compile(
    r"\b(summarize|summarise|tl;?dr|short version|in one sentence|"
    r"brief(ly)?|recap|condense)\b",
    re.IGNORECASE,
)

_CHEAP_MODEL = "gpt-4o-mini"
_STRONG_MODEL = "gpt-4o"


@dataclass
class RouteDecision:
    """The provider/model chosen for a request, plus a human-readable reason."""

    provider_name: str
    model: str
    reason: str


def classify_task(user_query: str) -> str:
    """Classify a user query into a coarse task type.

    Args:
        user_query: The raw text of the user's latest message.

    Returns:
        One of ``"summary"``, ``"code_or_reasoning"``, or ``"general"``.
    """
    if _CODE_HINTS.search(user_query):
        return "code_or_reasoning"
    if _SUMMARY_HINTS.search(user_query):
        return "summary"
    if len(user_query.split()) <= 12:
        return "summary"
    return "general"


def resolve_route(
    requested_model: str, user_query: str, settings: Settings
) -> RouteDecision:
    """Decide which provider and model to use for this request.

    Resolution order:

    1. If ``requested_model`` is not ``"auto"``, honor it literally and
       pick whichever provider has credentials (FastRouter preferred,
       then OpenAI, then mock).
    2. If ``requested_model == "auto"``, classify the task:
       - ``summary`` tasks use the cheaper model.
       - ``code_or_reasoning`` tasks use the stronger model.
       - everything else uses ``settings.default_model``.
       Then pick a provider: FastRouter if configured, else OpenAI if
       configured, else mock.

    Args:
        requested_model: The ``model`` field from the incoming request.
        user_query: The latest user message content, used for task
            classification when ``requested_model == "auto"``.
        settings: Current proxy settings (credentials, defaults).

    Returns:
        A :class:`RouteDecision` describing the chosen provider and model.
    """
    if requested_model and requested_model.lower() != "auto":
        provider_name = _pick_provider(settings)
        return RouteDecision(
            provider_name=provider_name,
            model=requested_model,
            reason=f"explicit model '{requested_model}' requested by client",
        )

    task_type = classify_task(user_query)
    if task_type == "summary":
        model = _CHEAP_MODEL
        reason = "auto-routed: simple/short query classified as summary task"
    elif task_type == "code_or_reasoning":
        model = _STRONG_MODEL
        reason = "auto-routed: query classified as code/reasoning task"
    else:
        model = settings.default_model
        reason = "auto-routed: general task, using configured default model"

    provider_name = _pick_provider(settings)
    return RouteDecision(provider_name=provider_name, model=model, reason=reason)


def _pick_provider(settings: Settings) -> str:
    """Pick a provider name based on configured credentials and defaults."""
    if settings.default_provider == "fastrouter" and settings.has_fastrouter:
        return "fastrouter"
    if settings.default_provider == "openai" and settings.has_openai:
        return "openai"
    if settings.has_fastrouter:
        return "fastrouter"
    if settings.has_openai:
        return "openai"
    return "mock"


def build_provider(provider_name: str, settings: Settings):
    """Instantiate the concrete provider object for ``provider_name``.

    Args:
        provider_name: One of ``"openai"``, ``"fastrouter"``, ``"mock"``.
        settings: Current proxy settings, used for credentials/base URLs.

    Returns:
        A provider instance exposing an async ``complete`` method.

    Raises:
        ValueError: If ``provider_name`` is unrecognized, or required
            credentials are missing for the requested provider.
    """
    if provider_name == "openai":
        if not settings.has_openai:
            raise ValueError("OpenAI provider requested but OPENAI_API_KEY is not set")
        return OpenAIProvider(api_key=settings.openai_api_key)  # type: ignore[arg-type]
    if provider_name == "fastrouter":
        if not settings.has_fastrouter:
            raise ValueError(
                "FastRouter provider requested but FASTROUTER_API_KEY is not set"
            )
        return FastRouterProvider(
            api_key=settings.fastrouter_api_key,  # type: ignore[arg-type]
            base_url=settings.fastrouter_base_url,
        )
    if provider_name == "mock":
        return MockProvider()
    raise ValueError(f"Unknown provider: {provider_name}")
