"""Core orchestration: ties together retrieval, optimization, compilation,
routing, provider invocation, and replay recording for a single request.
"""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from contextos_proxy.config import Settings
from contextos_proxy.context_optimizer import optimize_context
from contextos_proxy.prompt_compiler import compile_prompt
from contextos_proxy.providers import ProviderError
from contextos_proxy.replay import build_replay_record, new_request_id
from contextos_proxy.router import build_provider, resolve_route
from contextos_proxy.semantic_graph import SemanticGraph
from contextos_proxy.storage.memory_store import MemoryStore
from contextos_proxy.token_meter import count_tokens


class ChatMessage(BaseModel):
    """A single OpenAI-style chat message."""

    role: str
    content: str


class ChatCompletionRequest(BaseModel):
    """OpenAI-compatible chat completion request body."""

    model: str = "auto"
    messages: List[ChatMessage]
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    top_p: Optional[float] = None
    n: Optional[int] = None
    stop: Optional[Any] = None
    stream: Optional[bool] = False


class ChatCompletionChoiceMessage(BaseModel):
    """The ``message`` field of a chat completion choice."""

    role: str = "assistant"
    content: str


class ChatCompletionChoice(BaseModel):
    """A single choice within a chat completion response."""

    index: int = 0
    message: ChatCompletionChoiceMessage
    finish_reason: str = "stop"


class ChatCompletionUsage(BaseModel):
    """Token usage accounting for a chat completion response."""

    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


class ChatCompletionResponse(BaseModel):
    """OpenAI-compatible chat completion response body."""

    id: str
    object: str = "chat.completion"
    created: int
    model: str
    choices: List[ChatCompletionChoice]
    usage: ChatCompletionUsage
    contextos: Dict[str, Any] = Field(default_factory=dict)


class ContextIngestRequest(BaseModel):
    """Request body for ``POST /v1/context/ingest``."""

    text: str
    source: str = "unknown"
    metadata: Dict[str, Any] = Field(default_factory=dict)


class ContextIngestResponse(BaseModel):
    """Response body for ``POST /v1/context/ingest``."""

    source: str
    facts_extracted: int
    facts: List[str]
    graph_nodes: int
    graph_edges: int


class ContextOSProxy:
    """Stateful orchestrator wiring together all proxy pipeline stages."""

    def __init__(
        self,
        settings: Settings,
        graph: SemanticGraph,
        memory_store: MemoryStore,
        on_graph_change=None,
    ) -> None:
        self.settings = settings
        self.graph = graph
        self.memory_store = memory_store
        self._on_graph_change = on_graph_change

    def ingest(self, request: ContextIngestRequest) -> ContextIngestResponse:
        """Extract semantic facts from raw text and store them in the graph.

        Args:
            request: The ingestion request containing text/source/metadata.

        Returns:
            A summary of how many facts were extracted and current graph
            size.
        """
        from contextos_proxy.semantic_graph import extract_facts

        facts = extract_facts(request.text, source=request.source)
        self.graph.add_facts(facts)
        if self._on_graph_change:
            self._on_graph_change()

        return ContextIngestResponse(
            source=request.source,
            facts_extracted=len(facts),
            facts=[f.as_sentence() for f in facts],
            graph_nodes=self.graph.node_count(),
            graph_edges=self.graph.edge_count(),
        )

    async def chat_completion(
        self, request: ChatCompletionRequest
    ) -> ChatCompletionResponse:
        """Run the full pipeline for an OpenAI-compatible chat request.

        Pipeline stages: prompt interception -> semantic graph retrieval
        -> context optimization -> prompt compilation -> model routing ->
        provider call -> OpenAI-compatible response -> replay recording.

        Args:
            request: The parsed chat completion request.

        Returns:
            An OpenAI-compatible :class:`ChatCompletionResponse`.

        Raises:
            ProviderError: If the underlying provider call fails.
        """
        request_id = new_request_id()

        user_query = self._extract_user_query(request.messages)
        original_prompt_tokens = count_tokens(user_query)

        candidate_facts = self.graph.search(user_query, limit=30)
        optimization = optimize_context(candidate_facts, self.settings.token_budget)

        compiled_prompt = compile_prompt(user_query, optimization.facts)

        route = resolve_route(request.model, user_query, self.settings)
        provider = build_provider(route.provider_name, self.settings)

        provider_messages = self._build_provider_messages(
            request.messages, compiled_prompt
        )

        try:
            provider_response = await provider.complete(
                model=route.model,
                messages=provider_messages,
                temperature=request.temperature,
                max_tokens=request.max_tokens,
                top_p=request.top_p,
                n=request.n,
                stop=request.stop,
            )
        except ProviderError:
            raise

        total_original_tokens = original_prompt_tokens + optimization.original_tokens
        total_optimized_tokens = original_prompt_tokens + optimization.optimized_tokens
        from contextos_proxy.token_meter import savings_percent

        overall_savings = savings_percent(total_original_tokens, total_optimized_tokens)

        record = build_replay_record(
            request_id=request_id,
            original_prompt=user_query,
            optimized_prompt=compiled_prompt,
            facts=optimization.facts,
            original_tokens=total_original_tokens,
            optimized_tokens=total_optimized_tokens,
            tokens_saved_percent=overall_savings,
            selected_provider=route.provider_name,
            selected_model=provider_response.model,
            response_text=provider_response.content,
        )
        self.memory_store.add(record.model_dump())

        usage = ChatCompletionUsage(
            prompt_tokens=provider_response.prompt_tokens,
            completion_tokens=provider_response.completion_tokens,
            total_tokens=provider_response.prompt_tokens
            + provider_response.completion_tokens,
        )

        return ChatCompletionResponse(
            id=request_id,
            created=int(time.time()),
            model=provider_response.model,
            choices=[
                ChatCompletionChoice(
                    index=0,
                    message=ChatCompletionChoiceMessage(
                        role="assistant", content=provider_response.content
                    ),
                    finish_reason=provider_response.finish_reason,
                )
            ],
            usage=usage,
            contextos={
                "request_id": request_id,
                "provider": route.provider_name,
                "routing_reason": route.reason,
                "facts_used": len(optimization.facts),
                "tokens_saved_percent": overall_savings,
            },
        )

    @staticmethod
    def _extract_user_query(messages: List[ChatMessage]) -> str:
        """Find the content of the most recent ``user`` message."""
        for message in reversed(messages):
            if message.role == "user":
                return message.content
        # Fall back to the last message of any role if no user message exists.
        if messages:
            return messages[-1].content
        return ""

    @staticmethod
    def _build_provider_messages(
        original_messages: List[ChatMessage], compiled_prompt: str
    ) -> List[Dict[str, str]]:
        """Replace the latest user message's content with the compiled prompt.

        Preceding conversation history (system/assistant/earlier user
        turns) is preserved so multi-turn conversations keep working.
        """
        result: List[Dict[str, str]] = [
            {"role": m.role, "content": m.content} for m in original_messages
        ]
        for idx in range(len(result) - 1, -1, -1):
            if result[idx]["role"] == "user":
                result[idx]["content"] = compiled_prompt
                break
        else:
            result.append({"role": "user", "content": compiled_prompt})
        return result
