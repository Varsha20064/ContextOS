"""Token counting utilities.

Uses ``tiktoken`` when available for accurate OpenAI-style token counts,
and falls back to a deterministic whitespace/character heuristic when
``tiktoken`` cannot be loaded (e.g. no network access to fetch encoder
files in a fully offline environment).
"""

from __future__ import annotations

import re

_ENCODER = None
_ENCODER_LOAD_ATTEMPTED = False


def _get_encoder():
    """Lazily load a tiktoken encoder, caching the result (or failure)."""
    global _ENCODER, _ENCODER_LOAD_ATTEMPTED
    if _ENCODER_LOAD_ATTEMPTED:
        return _ENCODER
    _ENCODER_LOAD_ATTEMPTED = True
    try:
        import tiktoken

        _ENCODER = tiktoken.get_encoding("cl100k_base")
    except Exception:
        _ENCODER = None
    return _ENCODER


def count_tokens(text: str) -> int:
    """Count the number of tokens in ``text``.

    Args:
        text: Arbitrary text content.

    Returns:
        An integer token count. Uses tiktoken's ``cl100k_base`` encoding
        when available; otherwise approximates using a word/punctuation
        split, which is a reasonable stand-in for token count for
        English-language text.
    """
    if not text:
        return 0

    encoder = _get_encoder()
    if encoder is not None:
        return len(encoder.encode(text))

    # Heuristic fallback: split on whitespace and punctuation boundaries.
    tokens = re.findall(r"\w+|[^\w\s]", text, re.UNICODE)
    return len(tokens)


def savings_percent(original: int, optimized: int) -> float:
    """Compute the percentage of tokens saved by optimization.

    Args:
        original: Token count before optimization.
        optimized: Token count after optimization.

    Returns:
        A percentage (0-100, can be negative if optimization expanded the
        content) rounded to two decimal places. Returns 0.0 if ``original``
        is zero to avoid division-by-zero.
    """
    if original <= 0:
        return 0.0
    saved = (original - optimized) / original * 100.0
    return round(saved, 2)
