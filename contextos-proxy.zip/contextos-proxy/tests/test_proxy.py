"""Tests for ContextOS Proxy.

These tests run entirely offline using the built-in mock provider
(no API keys are required or used).
"""

from __future__ import annotations

import os
import shutil
import tempfile

import pytest
from fastapi.testclient import TestClient


@pytest.fixture()
def client(monkeypatch):
    """Build a TestClient against a fresh, isolated storage directory."""
    tmp_dir = tempfile.mkdtemp(prefix="contextos-test-")
    monkeypatch.setenv("CONTEXTOS_STORAGE_DIR", tmp_dir)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("FASTROUTER_API_KEY", raising=False)
    monkeypatch.setenv("DEFAULT_PROVIDER", "mock")

    import contextos_proxy.config as config_module

    config_module.reload_settings()

    # Reload the server module fresh so it picks up the patched settings
    # and isolated storage directory.
    import importlib

    import contextos_proxy.server as server_module

    importlib.reload(server_module)

    with TestClient(server_module.app) as test_client:
        yield test_client

    shutil.rmtree(tmp_dir, ignore_errors=True)


def test_health(client):
    """The /health endpoint reports ok status and mock mode."""
    response = client.get("/health")
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "ok"
    assert body["mode"] == "mock"


def test_ingest_extracts_facts(client):
    """Ingesting text with recognizable relations extracts graph facts."""
    text = (
        "OrbitGuard is a kind of satellite monitoring platform. "
        "OrbitGuard depends on the TelemetryIngestor service. "
        "TelemetryIngestor uses Apache Kafka."
    )
    response = client.post(
        "/v1/context/ingest",
        json={"text": text, "source": "test_doc", "metadata": {"k": "v"}},
    )
    assert response.status_code == 200
    body = response.json()
    assert body["facts_extracted"] >= 2
    assert body["graph_nodes"] > 0
    assert body["graph_edges"] >= 2


def test_ingest_rejects_empty_text(client):
    """Empty ingestion text is rejected with a 400."""
    response = client.post(
        "/v1/context/ingest", json={"text": "   ", "source": "x", "metadata": {}}
    )
    assert response.status_code == 400


def test_chat_completion_returns_openai_shape(client):
    """Chat completions return an OpenAI-compatible response shape."""
    client.post(
        "/v1/context/ingest",
        json={
            "text": "OrbitGuard depends on the TelemetryIngestor service.",
            "source": "test_doc",
            "metadata": {},
        },
    )

    response = client.post(
        "/v1/chat/completions",
        json={
            "model": "auto",
            "messages": [
                {"role": "user", "content": "Explain OrbitGuard architecture"}
            ],
        },
    )
    assert response.status_code == 200
    body = response.json()
    assert body["object"] == "chat.completion"
    assert "id" in body
    assert body["choices"][0]["message"]["role"] == "assistant"
    assert isinstance(body["choices"][0]["message"]["content"], str)
    assert "usage" in body
    assert body["usage"]["total_tokens"] >= 0
    assert "contextos" in body
    assert body["contextos"]["provider"] == "mock"


def test_chat_completion_rejects_empty_messages(client):
    """An empty messages list is rejected with a 400."""
    response = client.post(
        "/v1/chat/completions", json={"model": "auto", "messages": []}
    )
    assert response.status_code == 400


def test_replay_lookup_after_chat(client):
    """A served chat request can be retrieved via the replay endpoint."""
    chat_response = client.post(
        "/v1/chat/completions",
        json={
            "model": "auto",
            "messages": [{"role": "user", "content": "Summarize this in short"}],
        },
    )
    request_id = chat_response.json()["id"]

    replay_response = client.get(f"/v1/replay/{request_id}")
    assert replay_response.status_code == 200
    record = replay_response.json()
    assert record["request_id"] == request_id
    assert "original_prompt" in record
    assert "optimized_prompt" in record


def test_replay_missing_returns_404(client):
    """Requesting an unknown replay id returns 404."""
    response = client.get("/v1/replay/req_does_not_exist")
    assert response.status_code == 404


def test_replay_list(client):
    """The replay list endpoint returns recent records."""
    client.post(
        "/v1/chat/completions",
        json={"model": "auto", "messages": [{"role": "user", "content": "hello"}]},
    )
    response = client.get("/v1/replay")
    assert response.status_code == 200
    body = response.json()
    assert body["count"] >= 1
    assert isinstance(body["records"], list)


def test_stats_endpoint(client):
    """The stats endpoint returns graph and usage aggregates."""
    response = client.get("/v1/stats")
    assert response.status_code == 200
    body = response.json()
    assert "graph_nodes" in body
    assert "graph_edges" in body
    assert "total_requests_served" in body


def test_graph_endpoint(client):
    """The graph endpoint returns nodes/edges JSON."""
    client.post(
        "/v1/context/ingest",
        json={
            "text": "AlertEngine sends notifications to OpsDashboard.",
            "source": "test_doc",
            "metadata": {},
        },
    )
    response = client.get("/v1/graph")
    assert response.status_code == 200
    body = response.json()
    assert "nodes" in body
    assert "edges" in body
    assert len(body["nodes"]) > 0


def test_auto_routing_classifies_code_task():
    """The router classifies code-related queries as code_or_reasoning."""
    from contextos_proxy.router import classify_task

    assert classify_task("Help me debug this Python function") == "code_or_reasoning"
    assert classify_task("Summarize this document briefly") == "summary"
    assert classify_task("hi") == "summary"


def test_context_optimizer_dedupes_and_budgets():
    """The optimizer removes duplicates and respects the token budget."""
    from contextos_proxy.context_optimizer import optimize_context
    from contextos_proxy.semantic_graph import Fact

    facts = [
        Fact(subject="A", relation="uses", obj="B", source="s"),
        Fact(subject="A", relation="uses", obj="B", source="s"),
        Fact(subject="C", relation="depends on", obj="D", source="s"),
    ]
    result = optimize_context(facts, token_budget=1000)
    assert len(result.facts) == 2  # duplicate removed

    tiny_budget_result = optimize_context(facts, token_budget=1)
    assert len(tiny_budget_result.facts) <= 1


def test_extract_facts_recognizes_relations():
    """The fact extractor recognizes common relation verbs/phrases."""
    from contextos_proxy.semantic_graph import extract_facts

    text = "OrbitGuard depends on TelemetryIngestor. TelemetryIngestor uses Kafka."
    facts = extract_facts(text, source="unit_test")
    assert len(facts) == 2
    sentences = [f.as_sentence() for f in facts]
    assert any("depends on" in s for s in sentences)
    assert any("uses" in s for s in sentences)
