# ContextOS Proxy

**An OpenAI-compatible semantic context gateway** that gives AI agents the
right graph-based memory, an optimized prompt, and the best available model
— without changing your application logic.

## What it is (and isn't)

ContextOS Proxy is **middleware**, not a product you talk to:

- ❌ It is **not** a chatbot. There is no UI to converse with directly.
- ❌ It is **not** a SaaS dashboard. There's no hosted service or login.
- ✅ It **is** a local-first proxy server that sits between your application
  (or IDE, agent, or SaaS backend) and LLM providers (OpenAI, FastRouter, or
  a local Mock provider).

You point your existing OpenAI SDK client at ContextOS Proxy instead of
`api.openai.com`. The proxy transparently:

1. Intercepts the prompt.
2. Retrieves relevant facts from a local semantic graph.
3. Optimizes/compresses that context to fit a token budget.
4. Compiles a structured prompt (Goal / Query / Context / Constraints / Output Format).
5. Routes the request to the best model (`model="auto"`) or honors an explicit model.
6. Calls OpenAI, FastRouter, or a Mock provider.
7. Returns an OpenAI-compatible response — plus replay/trace metadata.

## Architecture

```
User App / Agent / IDE / SaaS
            │
            ▼
     ContextOS Proxy
            │
            ▼
    Prompt Interceptor
            │
            ▼
  Semantic Graph Retriever
            │
            ▼
    Context Optimizer
            │
            ▼
    Prompt Compiler
            │
            ▼
     Model Router
            │
            ▼
 OpenAI / FastRouter / Mock
            │
            ▼
 OpenAI-compatible response
```

## Install

```bash
git clone https://github.com/your-org/contextos-proxy.git
cd contextos-proxy
pip install -e ".[dev]"
```

This installs the `contextos_proxy` package and registers the
`contextos-proxy` CLI command.

## Run locally

```bash
uvicorn contextos_proxy.server:app --host 0.0.0.0 --port 8787
```

or, equivalently, via the CLI:

```bash
contextos-proxy serve
```

No API keys are required to start the server. If neither `OPENAI_API_KEY`
nor `FASTROUTER_API_KEY` is set, the proxy automatically runs in **mock
mode** and returns valid, deterministic OpenAI-compatible responses — the
full pipeline (graph retrieval, optimization, routing, replay) still runs
end-to-end.

Copy `.env.example` to `.env` and fill in whichever credentials you have:

```bash
cp .env.example .env
```

## Ingest semantic context

Send raw text (docs, notes, architecture descriptions) to the ingestion
endpoint. ContextOS Proxy extracts `subject -> relation -> object` facts
using a deterministic, fully offline heuristic extractor and stores them in
a local NetworkX-backed graph:

```bash
curl -X POST http://localhost:8787/v1/context/ingest \
  -H "Content-Type: application/json" \
  -d '{
        "text": "OrbitGuard depends on the TelemetryIngestor service. TelemetryIngestor uses Apache Kafka.",
        "source": "architecture_notes",
        "metadata": {"team": "platform"}
      }'
```

Or use the CLI:

```bash
contextos-proxy ingest docs/architecture_notes.txt
```

See `examples/ingest_context.py` for a Python example.

## Use the OpenAI SDK against the proxy

Change only `base_url` (and use any placeholder API key — the proxy itself
doesn't require it, though you may use it as an internal auth token if you
add one):

```python
from openai import OpenAI

client = OpenAI(
    api_key="contextos-local-key",
    base_url="http://localhost:8787/v1",
)

response = client.chat.completions.create(
    model="auto",
    messages=[
        {"role": "user", "content": "Explain OrbitGuard architecture"}
    ],
)

print(response.choices[0].message.content)
```

Everything else — retrieval, optimization, routing — happens inside the
proxy. See `examples/openai_client_example.py`.

## How `model="auto"` works

When the client requests `model="auto"`, the **Model Router**
(`contextos_proxy/router.py`) classifies the latest user message:

- **Summary-like / short queries** (e.g. "summarize this", "tl;dr", or any
  very short message) → routed to a cheaper model (`gpt-4o-mini`).
- **Code or reasoning-heavy queries** (mentions of code, bugs, algorithms,
  architecture, debugging, etc.) → routed to a stronger model (`gpt-4o`).
- **Everything else** → routed to `DEFAULT_MODEL` from your environment.

Provider selection is independent of model selection:

1. If `DEFAULT_PROVIDER=fastrouter` and `FASTROUTER_API_KEY` is set → FastRouter.
2. Else if `DEFAULT_PROVIDER=openai` and `OPENAI_API_KEY` is set → OpenAI.
3. Else, whichever of FastRouter/OpenAI has a configured key is used.
4. If neither is configured → the local **Mock** provider.

If the client requests an explicit model (anything other than `"auto"`),
the router honors that model literally and only chooses the provider.

## How token savings are calculated

For every request, `contextos_proxy/context_optimizer.py`:

1. Retrieves candidate semantic graph facts relevant to the query
   (`SemanticGraph.search`).
2. **Deduplicates** exact-duplicate `subject/relation/object` triples.
3. Renders the deduplicated facts to text and counts tokens
   (`original_tokens`, via `tiktoken`'s `cl100k_base` encoding, with a
   deterministic offline fallback if `tiktoken` is unavailable).
4. Greedily keeps facts (in relevance order) until adding the next fact
   would exceed `TOKEN_BUDGET`, producing `optimized_tokens`.
5. Computes:

   ```
   tokens_saved_percent = (original_tokens - optimized_tokens) / original_tokens * 100
   ```

This is combined with the token count of the raw user query to produce the
overall `tokens_saved_percent` stored in each replay record and surfaced in
the `contextos` field of every chat completion response.

## Replay / tracing

Every request is fully traced. Inspect any past request:

```bash
curl http://localhost:8787/v1/replay/req_xxxxxxxxxxxxxxxxxxxxxxxx
curl http://localhost:8787/v1/replay
```

Each replay record contains: `request_id`, `original_prompt`,
`optimized_prompt`, `semantic_facts_used`, `original_tokens`,
`optimized_tokens`, `tokens_saved_percent`, `selected_provider`,
`selected_model`, `timestamp`, and `response_preview`.

## Utility endpoints

| Endpoint            | Description                                   |
|----------------------|------------------------------------------------|
| `GET /health`        | Liveness check, current mode (mock/live)       |
| `GET /v1/stats`      | Graph size, request count, avg. tokens saved   |
| `GET /v1/graph`      | Full semantic graph export (nodes + edges)     |
| `GET /v1/replay`     | List recent request traces                     |
| `GET /v1/replay/{id}`| Full trace for one request                     |

## CLI reference

```bash
contextos-proxy serve              # run the HTTP server
contextos-proxy ingest file.txt    # ingest a text file into the graph
contextos-proxy graph              # print the current graph as JSON
contextos-proxy stats              # print summary statistics
```

## Project structure

```
contextos-proxy/
├── contextos_proxy/
│   ├── server.py            # FastAPI app & routes
│   ├── config.py            # env-based settings
│   ├── proxy.py             # pipeline orchestration + OpenAI-compatible schemas
│   ├── router.py            # model/provider routing logic
│   ├── semantic_graph.py    # NetworkX graph + fact extraction + search
│   ├── context_optimizer.py # dedupe + token-budget compression
│   ├── prompt_compiler.py   # structured prompt construction
│   ├── replay.py            # trace record schema
│   ├── token_meter.py       # token counting utilities
│   ├── cli.py                # `contextos-proxy` CLI
│   ├── providers/            # openai / fastrouter / mock backends
│   └── storage/              # JSON-file-backed graph & replay persistence
├── examples/
├── tests/
├── pyproject.toml
├── .env.example
├── Dockerfile
└── LICENSE
```

## Running tests

```bash
pip install -e ".[dev]"
pytest
```

Tests run fully offline against the built-in Mock provider — no API keys
are needed.

## Docker

```bash
docker build -t contextos-proxy .
docker run -p 8787:8787 -v contextos-data:/data contextos-proxy
```

## License

MIT — see `LICENSE`.
